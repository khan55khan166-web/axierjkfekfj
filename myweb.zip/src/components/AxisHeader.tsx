/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, Menu, Shield } from 'lucide-react';
import AxisLogo from './AxisLogo';

interface AxisHeaderProps {
  onBack?: () => void;
  showBack?: boolean;
  onMenuToggle?: () => void;
  showMenu?: boolean;
  isSecure?: boolean;
}

export default function AxisHeader({
  onBack,
  showBack = false,
  onMenuToggle,
  showMenu = true,
  isSecure = false,
}: AxisHeaderProps) {
  return (
    <div className="sticky top-0 z-30 flex flex-col" id="header-and-subheader-wrapper">
      {/* Primary Navigation Bar */}
      <header 
        className="bg-white border-b border-gray-100 py-3 px-4 md:px-6 flex items-center justify-between shadow-xs"
        id="axis-app-header"
      >
        <div className="flex items-center gap-3" id="header-left-section">
          {showBack && onBack ? (
            <button
              onClick={onBack}
              className="p-1.5 rounded-full hover:bg-rose-50 text-[#AE275F] transition-colors cursor-pointer"
              aria-label="Go back"
              id="header-back-button"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
          ) : null}
          
          <AxisLogo className="h-8 md:h-9" variant="color" showText={true} />
        </div>

        <div className="flex items-center gap-3" id="header-right-section">
          {isSecure && (
            <div 
              className="flex items-center gap-1.5 bg-green-50 text-emerald-700 px-2.5 py-1 rounded-full text-xs font-semibold tracking-wider uppercase border border-emerald-100"
              id="secure-badge"
            >
              <Shield className="w-3.5 h-3.5 fill-emerald-100" />
              <span>100% SECURE</span>
            </div>
          )}

          {showMenu && onMenuToggle && (
            <button
              onClick={onMenuToggle}
              className="p-2 rounded-lg hover:bg-rose-50 text-[#AE275F] transition-colors cursor-pointer flex items-center justify-center"
              aria-label="Open menu"
              id="header-menu-button"
            >
              <Menu className="w-6 h-6 text-[#AE275F]" />
            </button>
          )}
        </div>
      </header>

      {/* Secure Banking Session Info Bar Strip matching Image 1 */}
      <div 
        className="bg-[#ecf3f8] border-b border-sky-100/30 py-2 px-4 md:px-6 flex items-center justify-between text-[11px] md:text-xs text-[#4c6682] font-semibold tracking-tight"
        id="secure-banking-session-strip"
      >
        <div className="flex items-center gap-1.5" id="secure-strip-left">
          {/* Lock icon */}
          <span className="text-xs" role="img" aria-label="lock">🔒</span>
          <span>Secure Banking Session</span>
        </div>
        <div className="text-right font-medium text-slate-400" id="secure-strip-right">
          Last sync: Just now
        </div>
      </div>
    </div>
  );
}
