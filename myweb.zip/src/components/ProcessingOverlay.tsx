/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface ProcessingOverlayProps {
  isVisible: boolean;
  message?: string;
  submessage?: string;
}

export default function ProcessingOverlay({
  isVisible,
  message = 'Processing...',
  submessage = 'Do not refresh page',
}: ProcessingOverlayProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <div className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden" id="processing-overlay-container">
          {/* Faded blur backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs"
            id="processing-backdrop"
          />

          {/* Central Spinner Modal Card matching Image 5 */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="relative bg-white rounded-2xl p-6 max-w-[240px] w-full shadow-xl flex flex-col items-center justify-center text-center space-y-3 border border-gray-100 mx-4"
            id="processing-modal-card"
          >
            {/* Spinning Indicator circle matching Image */}
            <div className="relative w-12 h-12 flex items-center justify-center mb-2" id="processing-spinner-box">
              {/* Spinning dark accent segment - 270 degree arc in #AE275F */}
              <div 
                className="absolute inset-0 rounded-full border-[3px] border-transparent border-t-[#AE275F] border-r-[#AE275F] border-b-[#AE275F] animate-spin" 
                style={{ animationDuration: '1s' }}
                id="spinning-segment"
              />
            </div>

            {/* Status texts */}
            <div className="space-y-1" id="processing-texts">
              <h2 className="font-bold text-slate-800 text-lg md:text-xl tracking-tight" id="processing-message">
                {message}
              </h2>
              <p className="text-gray-500 text-xs md:text-sm font-medium" id="processing-submessage">
                {submessage}
              </p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
