/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Shield, Zap, Headphones, ChevronUp } from 'lucide-react';
import { AxisLogoIcon } from './AxisLogo';

// @ts-ignore
import defaultLogoImage from '../../images/AXISBANK.BO.png';

interface AxisFooterProps {
  onOpenSqlEditor?: () => void;
}

export default function AxisFooter({ onOpenSqlEditor }: AxisFooterProps) {
  const [customLogo, setCustomLogo] = useState<string | null>(defaultLogoImage);

  useEffect(() => {
    const handleStorageChange = () => {
      try {
        setCustomLogo(defaultLogoImage);
      } catch (e) {
        console.error(e);
      }
    };
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('custom-logo-updated', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('custom-logo-updated', handleStorageChange);
    };
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-white border-t border-gray-100 mt-12" id="axis-portal-footer">
      {/* 3-Column Trust Indicators Section matching Image 2 exactly */}
      <div className="max-w-xl mx-auto px-6 py-8 border-b border-gray-100" id="trust-indicators-section">
        <div className="grid grid-cols-3 gap-4 text-center items-stretch" id="trust-indicators-grid">
          {/* Secure Column */}
          <div className="flex flex-col items-center justify-start space-y-1" id="indicator-secure">
            <div className="w-10 h-10 flex items-center justify-center text-slate-700 mb-1" id="indicator-secure-icon">
              <Shield className="w-6 h-6 stroke-[2]" />
            </div>
            <p className="font-bold text-slate-800 text-xs md:text-sm tracking-tight leading-none">
              Secure
            </p>
            <p className="text-[10px] md:text-xs text-slate-400 font-medium">
              256-bit Encryption
            </p>
          </div>

          {/* Vertical divider */}
          <div className="hidden border-r border-gray-100" />

          {/* Fast Column */}
          <div className="flex flex-col items-center justify-start space-y-1 border-x border-gray-100 px-2" id="indicator-fast">
            <div className="w-10 h-10 flex items-center justify-center text-slate-700 mb-1" id="indicator-fast-icon">
              <Zap className="w-6 h-6 stroke-[2]" />
            </div>
            <p className="font-bold text-slate-800 text-xs md:text-sm tracking-tight leading-none">
              Fast
            </p>
            <p className="text-[10px] md:text-xs text-slate-400 font-medium">
              Instant Updates
            </p>
          </div>

          {/* 24/7 Column */}
          <div className="flex flex-col items-center justify-start space-y-1" id="indicator-support">
            <div className="w-10 h-10 flex items-center justify-center text-slate-700 mb-1" id="indicator-support-icon">
              <Headphones className="w-6 h-6 stroke-[2]" />
            </div>
            <p className="font-bold text-slate-800 text-xs md:text-sm tracking-tight leading-none">
              24/7
            </p>
            <p className="text-[10px] md:text-xs text-slate-400 font-medium">
              Dedicated Support
            </p>
          </div>
        </div>
      </div>

      {/* Main Brand, Tagline and Links Section */}
      <div className="max-w-xl mx-auto px-6 py-10 flex flex-col items-center text-center space-y-6" id="footer-branding-section">
        {/* Logo Icon */}
        <div className="flex justify-center" id="footer-logo-box">
          {customLogo ? (
            <img 
              src={customLogo} 
              alt="Custom Axis Logo" 
              className="h-12 max-w-[180px] object-contain rounded-md"
              id="footer-custom-logo"
              referrerPolicy="no-referrer"
            />
          ) : (
            <AxisLogoIcon className="w-12 h-12 text-[#AE275F]" color="#AE275F" />
          )}
        </div>

        {/* Tagline text matching Image 2 */}
        <p className="text-[#AE275F] italic font-sans font-medium text-sm md:text-base px-4" id="footer-tagline">
          Banking that is intuitive, secure, and rewarding.
        </p>

        {/* Footer Navigation Links */}
        <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs md:text-sm font-semibold text-[#AE275F]" id="footer-links-row">
          <a href="#about" className="hover:underline transition-all cursor-pointer">About Us</a>
          <a href="#privacy" className="hover:underline transition-all cursor-pointer">Privacy Policy</a>
          <a href="#terms" className="hover:underline transition-all cursor-pointer">Terms of Use</a>
          <a href="#contact" className="hover:underline transition-all cursor-pointer">Contact Support</a>
        </div>

        {/* Copyright Text */}
        <p className="text-[11px] md:text-xs text-gray-400 font-bold tracking-tight pt-2" id="footer-copyright-text">
          © 2026 Axis Bank Limited. All rights reserved.
        </p>
      </div>

      {/* Sticky Floating action scroll-to-top button */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-6 right-6 w-11 h-11 bg-[#AE275F] hover:bg-[#97144D] text-white rounded-2xl shadow-lg transition-transform hover:scale-105 cursor-pointer flex items-center justify-center active:scale-95 z-40"
        aria-label="Scroll to top"
        id="footer-scroll-top-btn"
      >
        <ChevronUp className="w-5 h-5 stroke-[2.5]" />
      </button>
    </footer>
  );
}
