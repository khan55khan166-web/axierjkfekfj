/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CheckCircle2, ShieldCheck, Home, ArrowLeft } from 'lucide-react';
import { ServiceInfo, ApplicantData, CardData } from '../types';

interface SuccessViewProps {
  service: ServiceInfo;
  applicant: ApplicantData;
  card: CardData;
  onHome: () => void;
}

export default function SuccessView({
  service,
  applicant,
  card,
  onHome,
}: SuccessViewProps) {
  const referenceId = React.useMemo(() => {
    return 'AXIS' + Math.floor(10000000 + Math.random() * 90000000);
  }, []);

  const maskedCard = React.useMemo(() => {
    if (!card.cardNumber) return '**** **** **** 4321';
    const clean = card.cardNumber.replace(/\s/g, '');
    return `**** **** **** ${clean.slice(-4)}`;
  }, [card.cardNumber]);

  return (
    <div className="max-w-md sm:max-w-xl mx-auto px-3 sm:px-4 py-4 sm:py-6 text-center space-y-4 sm:space-y-6" id="success-view-container">
      
      {/* Animated Checkmark and Title */}
      <div className="space-y-2 sm:space-y-3 py-2 sm:py-4" id="success-header-wrapper">
        <div className="flex justify-center" id="success-check-icon">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-500 border-2 border-emerald-100 shadow-md">
            <CheckCircle2 className="w-10 h-10 sm:w-12 sm:h-12 stroke-[2.5]" />
          </div>
        </div>
        <div className="space-y-0.5 sm:space-y-1">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight" id="success-title">
            Request Submitted!
          </h1>
          <p className="text-emerald-600 text-xs sm:text-sm font-bold tracking-wide" id="success-subtitle">
            Securely authorized and processed successfully
          </p>
        </div>
      </div>

      {/* Confirmation Details Card */}
      <div className="bg-white rounded-2xl sm:rounded-3xl border border-gray-100 shadow-sm p-4 sm:p-6 space-y-4 sm:space-y-5 text-left relative overflow-hidden" id="success-receipt-card">
        {/* Decorative accent */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-emerald-500" />
        
        <h2 className="font-extrabold text-gray-800 text-xs sm:text-sm md:text-base tracking-tight border-b border-gray-100 pb-2.5 sm:pb-3 uppercase tracking-wider">
          Transaction Receipt
        </h2>

        {/* Info grid */}
        <div className="grid grid-cols-2 gap-y-3 sm:gap-y-4 gap-x-2 text-xs sm:text-sm" id="receipt-grid">
          <div className="space-y-0.5" id="receipt-service-row">
            <p className="text-gray-400 font-bold uppercase text-[9px] tracking-wider">Service Requested</p>
            <p className="font-bold text-gray-800">{service.title}</p>
          </div>
          
          <div className="space-y-0.5" id="receipt-ref-row">
            <p className="text-gray-400 font-bold uppercase text-[9px] tracking-wider">Reference ID</p>
            <p className="font-mono font-extrabold text-[#AE275F] tracking-tight">{referenceId}</p>
          </div>

          <div className="space-y-0.5" id="receipt-holder-row">
            <p className="text-gray-400 font-bold uppercase text-[9px] tracking-wider">Cardholder Name</p>
            <p className="font-bold text-gray-800 truncate">{card.cardholderName || applicant.fullName}</p>
          </div>

          <div className="space-y-0.5" id="receipt-card-row">
            <p className="text-gray-400 font-bold uppercase text-[9px] tracking-wider">Card Number</p>
            <p className="font-mono font-bold text-gray-800">{maskedCard}</p>
          </div>

          <div className="col-span-2 space-y-0.5 border-t border-gray-100 pt-2.5 sm:pt-3" id="receipt-status-row">
            <p className="text-gray-400 font-bold uppercase text-[9px] tracking-wider">Status</p>
            <div className="flex items-center gap-1.5 text-emerald-700 font-extrabold text-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>ACTIVE & COMPLETED</span>
            </div>
          </div>
        </div>

        {/* Notification Alert */}
        <div className="bg-gray-50 rounded-xl sm:rounded-2xl p-3 sm:p-4 text-[11px] sm:text-xs text-gray-500 leading-relaxed font-medium" id="receipt-notification">
          A confirmation SMS and email with details about your <span className="font-bold text-gray-700">{service.title}</span> request have been dispatched to your registered contact details. Thank you for banking with Axis Bank.
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3 pt-1 sm:pt-2" id="success-actions">
        <button
          onClick={onHome}
          className="w-full bg-[#AE275F] hover:bg-[#97144D] active:bg-[#7A0C3C] text-white py-3.5 sm:py-4 px-5 rounded-xl sm:rounded-2xl font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer text-sm sm:text-base"
          id="btn-success-home"
        >
          <Home className="w-4 h-4 sm:w-5 sm:h-5" />
          <span>HOME</span>
        </button>

        <div className="flex items-center justify-center gap-1.5 mt-2 text-gray-400 text-[11px] sm:text-xs" id="success-secure-footer">
          <ShieldCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-500" />
          <span>Closed secure session ID successfully</span>
        </div>
      </div>
    </div>
  );
}
