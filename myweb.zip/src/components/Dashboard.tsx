/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Power, 
  Ban, 
  Receipt, 
  FileText, 
  Target, 
  TrendingUp, 
  Gift, 
  Globe,
  ChevronRight,
  ChevronUp,
  ShieldCheck,
  Sliders,
  Shield
} from 'lucide-react';
import { ServiceType } from '../types';
import { SERVICES_LIST } from '../data/services';
import PromoCarousel from './PromoCarousel';

interface DashboardProps {
  onSelectService: (type: ServiceType) => void;
}

export default function Dashboard({ onSelectService }: DashboardProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getServiceStyle = (type: ServiceType) => {
    switch (type) {
      case ServiceType.CARD_ACTIVATION:
        return { bg: 'bg-blue-50/70', text: 'text-blue-600', badgeBg: 'bg-blue-100/50', border: 'border-blue-100/40' };
      case ServiceType.CARD_DEACTIVATE:
        return { bg: 'bg-red-50/70', text: 'text-red-600', badgeBg: 'bg-red-100/50', border: 'border-red-100/40' };
      case ServiceType.PAY_BILL:
        return { bg: 'bg-emerald-50/70', text: 'text-emerald-600', badgeBg: 'bg-emerald-100/50', border: 'border-emerald-100/40' };
      case ServiceType.CARD_STATEMENTS:
        return { bg: 'bg-amber-50/70', text: 'text-amber-600', badgeBg: 'bg-amber-100/50', border: 'border-amber-100/40' };
      case ServiceType.CARD_PIN_GENERATION:
        return { bg: 'bg-purple-50/70', text: 'text-purple-600', badgeBg: 'bg-purple-100/50', border: 'border-purple-100/40' };
      case ServiceType.TRACK_STATUS:
        return { bg: 'bg-teal-50/70', text: 'text-teal-600', badgeBg: 'bg-teal-100/50', border: 'border-teal-100/40' };
      case ServiceType.LIMIT_INCREASE:
        return { bg: 'bg-cyan-50/70', text: 'text-cyan-600', badgeBg: 'bg-cyan-100/50', border: 'border-cyan-100/40' };
      case ServiceType.REWARD_REDEEM:
        return { bg: 'bg-rose-50/70', text: 'text-rose-600', badgeBg: 'bg-rose-100/50', border: 'border-rose-100/40' };
      case ServiceType.INTERNATIONAL_USAGE:
        return { bg: 'bg-indigo-50/70', text: 'text-indigo-600', badgeBg: 'bg-indigo-100/50', border: 'border-indigo-100/40' };
      case ServiceType.CARD_CONTROL_SETTINGS:
        return { bg: 'bg-orange-50/70', text: 'text-orange-600', badgeBg: 'bg-orange-100/50', border: 'border-orange-100/40' };
      case ServiceType.CARD_PROTECTION_PLAN:
        return { bg: 'bg-cyan-50/70', text: 'text-cyan-600', badgeBg: 'bg-cyan-100/50', border: 'border-cyan-100/40' };
      default:
        return { bg: 'bg-gray-50/70', text: 'text-gray-600', badgeBg: 'bg-gray-100/50', border: 'border-gray-100/40' };
    }
  };

  const renderServiceIcon = (iconName: string, textClass: string) => {
    const iconClass = `w-6 h-6 ${textClass}`;
    switch (iconName) {
      case 'Power':
        return <Power className={iconClass} />;
      case 'Ban':
        return <Ban className={iconClass} />;
      case 'Receipt':
        return <Receipt className={iconClass} />;
      case 'FileText':
        return <FileText className={iconClass} />;
      case 'Numeric':
        return (
          <div className="w-6 h-6 bg-rose-800 text-white rounded-lg flex items-center justify-center font-bold text-xs tracking-tight">
            123
          </div>
        );
      case 'Target':
        return <Target className={iconClass} />;
      case 'TrendingUp':
        return <TrendingUp className={iconClass} />;
      case 'Gift':
        return <Gift className={iconClass} />;
      case 'Globe':
        return <Globe className={iconClass} />;
      case 'Sliders':
        return <Sliders className={iconClass} />;
      case 'Shield':
        return <Shield className={iconClass} />;
      default:
        return <FileText className={iconClass} />;
    }
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-4 space-y-6" id="dashboard-content-wrapper">
      {/* Welcome Message */}
      <div className="text-left py-2" id="dashboard-welcome-banner">
        <h1 className="text-2xl md:text-3xl font-extrabold text-[#AE275F] tracking-tight">
          Welcome to Axis Services
        </h1>
        <p className="text-gray-500 text-xs md:text-sm mt-1">
          Manage your credit cards, track benefits, and upgrade limits instantly and securely. Select a service to begin.
        </p>
      </div>

      {/* Promotional Slides Slider (PromoCarousel) */}
      <PromoCarousel onSelectService={onSelectService} />

      {/* Grid containing all 9 Services matching the Sidebar */}
      <div className="space-y-4" id="dashboard-services-grid">
        {SERVICES_LIST.map((service) => {
          const style = getServiceStyle(service.type);
          return (
            <div
              key={service.type}
              onClick={() => onSelectService(service.type)}
              className={`bg-white rounded-2xl border ${style.border} shadow-xs hover:shadow-md hover:scale-[1.01] hover:border-rose-200 transition-all duration-200 p-5 flex gap-4 relative overflow-hidden cursor-pointer group`}
              id={`dashboard-card-${service.type}`}
            >
              {/* Colored side-bar accent line */}
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-rose-800 opacity-0 group-hover:opacity-100 transition-opacity" />

              {/* Icon Container */}
              <div className="flex-shrink-0">
                <div className={`w-12 h-12 rounded-2xl ${style.bg} flex items-center justify-center group-hover:scale-105 transition-transform`} id={`icon-box-${service.type}`}>
                  {renderServiceIcon(service.iconName, style.text)}
                </div>
              </div>

              {/* Card Body */}
              <div className="flex-1 space-y-3" id={`body-${service.type}`}>
                <div className="text-left pr-4">
                  <h3 className="font-extrabold text-gray-800 text-base md:text-lg tracking-tight group-hover:text-rose-900 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-gray-400 text-[11px] font-bold tracking-wide uppercase mt-0.5">
                    {service.subtitle}
                  </p>
                  <p className="text-gray-500 text-xs md:text-sm leading-relaxed mt-1.5 font-medium">
                    {service.description}
                  </p>
                </div>

                {/* Primary Action Button */}
                {service.type === ServiceType.CARD_PROTECTION_PLAN ? (
                  <div className="flex flex-wrap items-center gap-2.5 pt-1" id={`actions-${service.type}`}>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectService(service.type);
                      }}
                      className="px-6 py-2.5 bg-[#AE275F] hover:bg-[#97144D] active:bg-[#7A0C3C] active:scale-[0.97] text-white rounded-xl text-xs md:text-sm font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center gap-1.5 cursor-pointer touch-manipulation select-none"
                      id={`btn-activation-${service.type}`}
                    >
                      <span>Activation</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectService(service.type);
                      }}
                      className="px-6 py-2.5 bg-[#AE275F] hover:bg-[#97144D] active:bg-[#7A0C3C] active:scale-[0.97] text-white rounded-xl text-xs md:text-sm font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center gap-1.5 cursor-pointer touch-manipulation select-none"
                      id={`btn-deactivation-${service.type}`}
                    >
                      <span>Deactivation</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 pt-1" id={`actions-${service.type}`}>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectService(service.type);
                      }}
                      className="px-8 py-3 bg-[#AE275F] hover:bg-[#97144D] active:bg-[#7A0C3C] active:scale-[0.97] text-white rounded-xl text-sm md:text-base font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center gap-1.5 cursor-pointer touch-manipulation select-none"
                      id={`btn-proceed-${service.type}`}
                    >
                      <span>Proceed</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>


    </div>
  );
}

