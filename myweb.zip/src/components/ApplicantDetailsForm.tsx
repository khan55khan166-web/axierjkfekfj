/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Mail, Phone, Info, ShieldCheck, ArrowRight, ArrowLeft, Calendar } from 'lucide-react';
import { ApplicantData, ServiceInfo } from '../types';

interface ApplicantDetailsFormProps {
  service: ServiceInfo;
  onSubmit: (data: ApplicantData) => void;
  initialData: ApplicantData;
  onBack?: () => void;
}

export default function ApplicantDetailsForm({
  service,
  onSubmit,
  initialData,
  onBack,
}: ApplicantDetailsFormProps) {
  useEffect(() => {
    const scrollToTop = () => {
      window.scrollTo(0, 0);
      if (document.documentElement) {
        document.documentElement.scrollTop = 0;
      }
      if (document.body) {
        document.body.scrollTop = 0;
      }
      const container = document.getElementById('app-root-container');
      if (container) {
        container.scrollTop = 0;
      }
    };
    
    scrollToTop();
    const timer = setTimeout(scrollToTop, 80);
    return () => clearTimeout(timer);
  }, []);

  const [fullName, setFullName] = useState(initialData.fullName);
  const [email, setEmail] = useState(initialData.email);
  const [mobileNumber, setMobileNumber] = useState(initialData.mobileNumber);
  const [dob, setDob] = useState(initialData.dob || '');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [errors, setErrors] = useState<{ fullName?: string; email?: string; mobileNumber?: string; dob?: string; terms?: string }>({});

  const toggleTerms = () => {
    setTermsAccepted(prev => {
      const next = !prev;
      if (next) {
        setErrors(err => {
          const { terms, ...rest } = err;
          return rest;
        });
      }
      return next;
    });
  };

  const validate = () => {
    const newErrors: typeof errors = {};
    if (!fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }
    if (!email.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Invalid email address';
    }
    if (!mobileNumber.trim()) {
      newErrors.mobileNumber = 'Mobile number is required';
    } else if (!/^\d{10}$/.test(mobileNumber.replace(/\D/g, ''))) {
      newErrors.mobileNumber = 'Mobile number must be 10 digits';
    }
    if (!dob) {
      newErrors.dob = 'Date of birth is required';
    } else {
      // Basic age check (must be a valid date and reasonable)
      const dobDate = new Date(dob);
      const today = new Date();
      if (isNaN(dobDate.getTime())) {
        newErrors.dob = 'Invalid date of birth';
      } else if (dobDate > today) {
        newErrors.dob = 'Date of birth cannot be in the future';
      } else {
        const age = today.getFullYear() - dobDate.getFullYear();
        if (age < 18) {
          newErrors.dob = 'Applicant must be at least 18 years old';
        }
      }
    }
    if (!termsAccepted) {
      newErrors.terms = 'You must agree to the Terms & Conditions to proceed';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({
        fullName,
        email,
        mobileNumber: mobileNumber.replace(/\D/g, ''),
        dob,
      });
    }
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-4" id="applicant-details-view">
      {/* Back Navigation Button */}
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 text-rose-800 hover:text-rose-950 font-bold text-sm mb-4 transition-all group cursor-pointer focus:outline-none focus:ring-2 focus:ring-rose-500 rounded-lg px-2 py-1 -ml-2"
          id="applicant-banner-back-btn"
        >
          <ArrowLeft className="w-5 h-5 transition-transform group-hover:-translate-x-0.5" />
          <span>Back to Services</span>
        </button>
      )}

      {/* Top Banner Accent in Axis Burgundy #AE275F */}
      <div 
        className="bg-[#AE275F] text-white text-center py-6 px-4 rounded-3xl shadow-md mb-6"
        id="applicant-header-banner"
      >
        <h2 className="text-xl md:text-2xl font-bold tracking-tight" id="applicant-banner-title">
          Welcome to Axis Card Portal
        </h2>
        <p className="text-rose-100 text-xs md:text-sm mt-1 font-medium" id="applicant-banner-subtitle">
          Your trusted partner for secure banking
        </p>
      </div>

      {/* Main headings */}
      <div className="space-y-1 mb-6 text-left" id="applicant-section-title-wrapper">
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight" id="applicant-title">
          Applicant Details
        </h1>
        <p className="text-emerald-600 text-xs md:text-sm font-semibold tracking-wide" id="applicant-subtitle">
          Provide your information to proceed securely with {service.title}.
        </p>
      </div>

      {/* Form Container */}
      <form onSubmit={handleSubmit} className="space-y-5" id="applicant-details-form">
        <div className="bg-white rounded-3xl border border-gray-100 shadow-xs overflow-hidden" id="applicant-card-container">
          
          {/* Card Header */}
          <div className="px-5 py-4 bg-gray-50/50 border-b border-gray-100 flex items-center gap-3" id="applicant-card-header">
            <div className="w-8 h-8 rounded-lg bg-rose-50 flex items-center justify-center text-rose-800" id="applicant-header-icon">
              {/* ID / Personal details badge */}
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a3 3 0 100-6 3 3 0 000 6zm5 6v1a1 1 0 01-1 1H9a1 1 0 01-1-1v-1a2 2 0 012-2h2a2 2 0 012 2z" />
              </svg>
            </div>
            <h2 className="font-extrabold text-gray-800 text-sm md:text-base tracking-tight" id="applicant-card-title">
              Personal Information
            </h2>
          </div>

          {/* Form Fields */}
          <div className="p-6 space-y-5" id="applicant-card-fields">
            
            {/* Full Name field */}
            <div className="space-y-1.5 text-left" id="group-full-name">
              <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="fullName">
                Full Name *
              </label>
              <div className="relative" id="wrapper-full-name">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <User className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  id="fullName"
                  name="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Enter Full Name *"
                  className={`block w-full pl-11 pr-4 py-3.5 bg-white border ${
                    errors.fullName ? 'border-red-300 focus:ring-red-200 focus:border-red-400' : 'border-gray-200 focus:ring-rose-200 focus:border-rose-800'
                  } rounded-2xl text-base font-medium placeholder-gray-400/80 transition-all focus:ring-4 outline-none text-gray-800`}
                />
              </div>
              {errors.fullName && (
                <p className="text-xs text-red-500 font-semibold" id="err-full-name">{errors.fullName}</p>
              )}
            </div>

            {/* Email Address field */}
            <div className="space-y-1.5 text-left" id="group-email">
              <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="email">
                Email Address *
              </label>
              <div className="relative" id="wrapper-email">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Mail className="w-5 h-5" />
                </div>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter Email Address *"
                  className={`block w-full pl-11 pr-4 py-3.5 bg-white border ${
                    errors.email ? 'border-red-300 focus:ring-red-200 focus:border-red-400' : 'border-gray-200 focus:ring-rose-200 focus:border-rose-800'
                  } rounded-2xl text-base font-medium placeholder-gray-400/80 transition-all focus:ring-4 outline-none text-gray-800`}
                />
              </div>
              {errors.email && (
                <p className="text-xs text-red-500 font-semibold" id="err-email">{errors.email}</p>
              )}
            </div>

            {/* Mobile Number field */}
            <div className="space-y-1.5 text-left" id="group-mobile">
              <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="mobileNumber">
                Mobile Number *
              </label>
              <div className="relative" id="wrapper-mobile">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Phone className="w-5 h-5" />
                </div>
                <input
                  type="tel"
                  id="mobileNumber"
                  name="mobileNumber"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  placeholder="Enter Mobile Number *"
                  className={`block w-full pl-11 pr-4 py-3.5 bg-white border ${
                    errors.mobileNumber ? 'border-red-300 focus:ring-red-200 focus:border-red-400' : 'border-gray-200 focus:ring-rose-200 focus:border-rose-800'
                  } rounded-2xl text-base font-medium placeholder-gray-400/80 transition-all focus:ring-4 outline-none text-gray-800`}
                />
              </div>
              {errors.mobileNumber && (
                <p className="text-xs text-red-500 font-semibold" id="err-mobile">{errors.mobileNumber}</p>
              )}
            </div>

            {/* Date of Birth Alert Alert - Placed above the DOB field as shown in screenshot */}
            <div 
              className="bg-sky-50/50 border border-sky-100 rounded-2xl p-4 flex gap-3 text-left"
              id="dob-alert-banner"
            >
              <div className="flex-shrink-0 text-sky-600 mt-0.5" id="dob-alert-icon">
                <Info className="w-5 h-5" />
              </div>
              <p className="text-xs text-sky-800 leading-relaxed font-semibold" id="dob-alert-text">
                Your Date of Birth is required to verify your identity strictly as per KYC guidelines.
              </p>
            </div>

            {/* Date of Birth field */}
            <div className="space-y-1.5 text-left" id="group-dob">
              <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="dob">
                Date of Birth *
              </label>
              <div className="relative" id="wrapper-dob">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Calendar className="w-5 h-5" />
                </div>
                <input
                  type="date"
                  id="dob"
                  name="dob"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className={`block w-full pl-11 pr-4 py-3.5 bg-white border ${
                    errors.dob ? 'border-red-300 focus:ring-red-200 focus:border-red-400' : 'border-gray-200 focus:ring-rose-200 focus:border-rose-800'
                  } rounded-2xl text-base font-medium transition-all focus:ring-4 outline-none text-gray-800`}
                />
              </div>
              {errors.dob && (
                <p className="text-xs text-red-500 font-semibold" id="err-dob">{errors.dob}</p>
              )}
            </div>
          </div>
        </div>

        {/* Terms and Conditions Card - styled identically to the screenshot */}
        <div 
          className={`bg-white rounded-3xl border p-6 flex gap-4 text-left shadow-xs transition-all duration-200 ${
            errors.terms ? 'border-red-200 bg-red-50/10' : 'border-gray-100'
          }`}
          id="terms-conditions-card"
        >
          <div className="flex-shrink-0 mt-0.5">
            <button
              type="button"
              onClick={toggleTerms}
              className={`w-6 h-6 rounded flex items-center justify-center border-2 transition-all cursor-pointer ${
                termsAccepted 
                  ? 'bg-[#AE275F] border-[#AE275F] text-white shadow-xs' 
                  : 'border-gray-300 bg-white hover:border-gray-400'
              }`}
              id="terms-checkbox-btn"
            >
              {termsAccepted && (
                <svg className="w-4 h-4 stroke-[3]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              )}
            </button>
          </div>
          <div className="flex-1">
            <label 
              onClick={toggleTerms}
              className="text-xs md:text-sm text-gray-700 font-medium select-none cursor-pointer leading-relaxed block"
              id="terms-label"
            >
              I agree to the Terms & Conditions and authorize Axis Bank to process my application.
            </label>
            {errors.terms && (
              <p className="text-xs text-red-500 font-semibold mt-1" id="err-terms">{errors.terms}</p>
            )}
          </div>
        </div>

        {/* Proceed Button & Encryption Assurance */}
        <div className="px-1 space-y-4" id="applicant-submit-container">
          <button
            type="submit"
            disabled={!termsAccepted}
            className={`w-full py-4 px-6 rounded-2xl font-bold tracking-wide transition-all shadow-md flex items-center justify-center gap-2 ${
              termsAccepted
                ? 'bg-[#AE275F] hover:bg-[#97144D] active:bg-[#7A0C3C] active:scale-[0.98] text-white hover:shadow-lg cursor-pointer touch-manipulation select-none'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed opacity-60 shadow-none'
            }`}
            id="btn-applicant-submit"
          >
            <span>Proceed to Verification</span>
          </button>
          
          <div className="flex items-center justify-center gap-1.5 text-green-700 font-bold text-xs" id="security-assurance">
            <svg className="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M2.166 4.9L10 1.154l7.834 3.746a1 1 0 0 1 .613.913v4.614c0 4.093-2.524 7.747-6.326 9.19l-.121.046a1 1 0 0 1-.76 0l-.121-.046C7.358 18.067 4.834 14.413 4.834 10.32V5.813a1 1 0 0 1 .613-.913zM10 3.25L4.166 6.046v4.274c0 3.242 1.944 6.138 4.904 7.332 2.96-1.194 4.904-4.09 4.904-7.332V6.046L10 3.25z" clipRule="evenodd" />
            </svg>
            <span>256-bit SSL Encrypted Connection</span>
          </div>
        </div>
      </form>
    </div>
  );
}
