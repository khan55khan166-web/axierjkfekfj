/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Gift, Power, Receipt, FileText, TrendingUp, ChevronLeft, ChevronRight } from 'lucide-react';
import { ServiceType } from '../types';

interface PromoSlide {
  id: string;
  title: string;
  emoji: string;
  description1: string;
  description2: string;
  gradientClass: string;
  circleBgClass: string;
  iconColorClass: string;
  icon: React.ReactNode;
  serviceType: ServiceType;
}

interface PromoCarouselProps {
  onSelectService: (type: ServiceType) => void;
}

export default function PromoCarousel({ onSelectService }: PromoCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(1); // Default to Slide 1 (Reward Points) to match the attached screenshot
  const [direction, setDirection] = useState(0); // For slide transitions (-1 for left, 1 for right)

  const slides: PromoSlide[] = [
    {
      id: 'card-activation',
      title: 'Card Activation',
      emoji: '⚡',
      description1: 'Activate your card instantly online.',
      description2: 'Secure your purchases and enjoy seamless transactions.',
      gradientClass: 'bg-gradient-to-r from-[#1e3c72] to-[#2a5298]',
      circleBgClass: 'bg-blue-100 text-blue-600',
      iconColorClass: 'text-blue-600',
      icon: <Power className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12" />,
      serviceType: ServiceType.CARD_ACTIVATION,
    },
    {
      id: 'reward-points',
      title: 'Reward Points',
      emoji: '🎁',
      description1: 'Redeem points for gifts and offers.',
      description2: 'Check your points balance regularly and get exclusive rewards.',
      gradientClass: 'bg-gradient-to-r from-[#9c144c] via-[#dd5a20] to-[#f49b10]',
      circleBgClass: 'bg-[#FFE02A]',
      iconColorClass: 'text-[#e54b1a]',
      icon: <Gift className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12" strokeWidth={2.2} />,
      serviceType: ServiceType.REWARD_REDEEM,
    },
    {
      id: 'pay-bill',
      title: 'Pay Card Bill',
      emoji: '💳',
      description1: 'Clear your card dues instantly & securely.',
      description2: 'Maintain your excellent credit score and unlock perks.',
      gradientClass: 'bg-gradient-to-r from-emerald-600 via-teal-600 to-teal-500',
      circleBgClass: 'bg-emerald-100 text-emerald-600',
      iconColorClass: 'text-emerald-600',
      icon: <Receipt className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12" />,
      serviceType: ServiceType.PAY_BILL,
    },
    {
      id: 'statements',
      title: 'Statements',
      emoji: '📊',
      description1: 'Access monthly statements securely.',
      description2: 'Track and analyze your transaction history up to 12 months.',
      gradientClass: 'bg-gradient-to-r from-slate-800 via-purple-900 to-indigo-950',
      circleBgClass: 'bg-purple-100 text-purple-600',
      iconColorClass: 'text-purple-600',
      icon: <FileText className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12" />,
      serviceType: ServiceType.CARD_STATEMENTS,
    },
    {
      id: 'limit-increase',
      title: 'Limit Increase',
      emoji: '📈',
      description1: 'Request high credit limit upgrades.',
      description2: 'Enjoy higher buying power and premium life privileges.',
      gradientClass: 'bg-gradient-to-r from-[#f12711] to-[#f5af19]',
      circleBgClass: 'bg-amber-100 text-amber-600',
      iconColorClass: 'text-amber-600',
      icon: <TrendingUp className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12" />,
      serviceType: ServiceType.LIMIT_INCREASE,
    },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setDirection(1);
      setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [slides.length]);

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % slides.length);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const handleDotClick = (index: number) => {
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  // Slider animation variants
  const slideVariants = {
    enter: (dir: number) => ({
      x: dir > 0 ? '100%' : '-100%',
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (dir: number) => ({
      x: dir < 0 ? '100%' : '-100%',
      opacity: 0,
    }),
  };

  const activeSlide = slides[currentIndex];

  return (
    <div 
      className="w-full relative"
      id="promo-carousel-container"
    >
      {/* Slide frame with fixed aspect ratio / overflow protection */}
      <div 
        className="w-full relative h-[180px] sm:h-[220px] md:h-[240px] rounded-[1.8rem] sm:rounded-[2.2rem] shadow-xl overflow-hidden cursor-pointer group"
        onClick={() => onSelectService(activeSlide.serviceType)}
        id="promo-carousel-slider-window"
      >
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: 'tween', duration: 0.4, ease: 'easeInOut' }}
            className={`absolute inset-0 p-6 sm:p-8 flex items-center justify-between ${activeSlide.gradientClass}`}
            id={`promo-slide-${activeSlide.id}`}
          >
            {/* Left Content Column */}
            <div className="flex-1 text-left select-none text-white flex flex-col justify-center h-full pr-2 sm:pr-6" id="promo-slide-content">
              {/* Header Title with Emoji */}
              <div className="flex items-center gap-2 mb-2 sm:mb-3">
                <span className="text-xl sm:text-2xl" role="img" aria-label="emoji">
                  {activeSlide.emoji}
                </span>
                <h2 className="text-lg sm:text-xl md:text-2xl font-bold tracking-tight text-white leading-tight">
                  {activeSlide.title}
                </h2>
              </div>
              
              {/* Description Paragraphs (properly aligned with clear structure) */}
              <p className="text-xs sm:text-sm md:text-base leading-snug sm:leading-relaxed text-white/90 font-medium">
                {activeSlide.description1}
              </p>
              <p className="text-xs sm:text-sm md:text-base leading-snug sm:leading-relaxed mt-0.5 sm:mt-1 text-white/85 font-normal">
                {activeSlide.description2}
              </p>
            </div>

            {/* Right Side Rounded Circular Badge */}
            <div className="flex-shrink-0 flex items-center justify-center pl-2" id="promo-slide-badge-container">
              <div 
                className={`w-14 h-14 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-full flex items-center justify-center transition-transform duration-300 group-hover:scale-108 active:scale-95 shadow-md ${activeSlide.circleBgClass}`}
                id="promo-slide-badge"
              >
                <div className={`${activeSlide.iconColorClass} flex items-center justify-center`}>
                  {activeSlide.icon}
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Styled Pagination Dots Indicator matching Image exactly */}
      <div className="flex justify-center items-center gap-2 mt-4" id="promo-carousel-dots">
        {slides.map((_, index) => {
          const isActive = index === currentIndex;
          return (
            <button
              key={index}
              onClick={() => handleDotClick(index)}
              className={`h-2 rounded-full transition-all duration-300 focus:outline-hidden cursor-pointer ${
                isActive 
                  ? 'bg-[#AE275F] w-7' // Elongated Axis Burgundy pill for active dot
                  : 'bg-gray-200 hover:bg-gray-300 w-2.5' // Small gray circle for inactive dots
              }`}
              aria-label={`Go to slide ${index + 1}`}
              id={`promo-carousel-dot-${index}`}
            />
          );
        })}
      </div>
    </div>
  );
}
