/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Power, 
  Ban, 
  Receipt, 
  FileText, 
  TrendingUp, 
  Gift, 
  Globe, 
  ChevronRight,
  Target,
  LogIn,
  Sliders,
  Shield,
} from 'lucide-react';
import { ServiceType, ServiceInfo } from '../types';
import { SERVICES_LIST } from '../data/services';
import { AxisLogoIcon } from './AxisLogo';

// @ts-ignore
import defaultLogoImage from '../../images/AXISBANK.BO.png';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectService: (type: ServiceType) => void;
  onLogin?: () => void;
  onOpenSqlEditor?: () => void;
  activeService?: ServiceType;
}

export default function Sidebar({
  isOpen,
  onClose,
  onSelectService,
  onLogin,
  onOpenSqlEditor,
  activeService,
}: SidebarProps) {
  const [customLogo, setCustomLogo] = useState<string | null>(defaultLogoImage);

  useEffect(() => {
    const handleStorageChange = () => {
      try {
        setCustomLogo(defaultLogoImage);
      } catch (e) {
        console.error(e);
      }
    };
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('custom-logo-updated', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('custom-logo-updated', handleStorageChange);
    };
  }, []);

  const renderIcon = (iconName: string) => {
    const iconClass = "w-6 h-6 text-[#AE275F]";
    switch (iconName) {
      case 'Power':
        return <Power className={iconClass} />;
      case 'Ban':
        return <Ban className={iconClass} />;
      case 'Receipt':
        return <Receipt className={iconClass} />;
      case 'FileText':
        return <FileText className={iconClass} />;
      case 'Numeric':
        return (
          <div className="w-[28px] h-[18px] bg-[#AE275F] text-white rounded flex items-center justify-center font-bold text-[8px] tracking-tighter" id="badge-123">
            123
          </div>
        );
      case 'Target':
        return <Target className={iconClass} />;
      case 'TrendingUp':
        return <TrendingUp className={iconClass} />;
      case 'Gift':
        return <Gift className={iconClass} />;
      case 'Globe':
        return <Globe className={iconClass} />;
      case 'Sliders':
        return <Sliders className={iconClass} />;
      case 'Shield':
        return <Shield className={iconClass} />;
      default:
        return <FileText className={iconClass} />;
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 z-40"
            id="sidebar-backdrop"
          />

          {/* Drawer Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="fixed top-0 right-0 h-full w-[80%] sm:w-full sm:max-w-[380px] bg-white shadow-2xl z-50 flex flex-col overflow-hidden rounded-l-[2.5rem]"
            id="sidebar-container"
          >
            {/* Header section matching Image 2 */}
            <div 
              className="relative p-6 text-white flex flex-col justify-end h-56 bg-gradient-to-b from-[#AE275F] to-[#670A32]"
              id="sidebar-header"
            >
              {/* Close Button */}
              <button
                onClick={onClose}
                className="absolute top-5 right-5 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                aria-label="Close sidebar"
                id="sidebar-close-button"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Logo Box */}
              <div 
                className="w-14 h-14 bg-white rounded-xl shadow-xs flex items-center justify-center mb-4"
                id="sidebar-logo-box"
              >
                {customLogo ? (
                  <div className="w-full h-full flex items-center justify-center p-1.5" id="sidebar-custom-logo-container">
                    <img 
                      src={customLogo} 
                      alt="Axis Bank Logo" 
                      className="max-w-full max-h-full object-contain rounded"
                      id="sidebar-custom-logo-img"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                ) : (
                  <div className="flex items-center justify-center w-full h-full" id="sidebar-default-logo-container">
                    <AxisLogoIcon className="w-8 h-8 text-[#AE275F]" color="#AE275F" />
                  </div>
                )}
              </div>

              {/* Sidebar branding */}
              <h2 className="text-xl font-bold tracking-tight" id="sidebar-title">
                Axis Bank Services
              </h2>
              <p className="text-rose-100/80 text-xs font-semibold mt-1" id="sidebar-subtitle">
                Credit Card Management
              </p>
            </div>

            {/* List items section */}
            <div className="flex-1 overflow-y-auto py-5 px-3 bg-white" id="sidebar-services-list">
              <nav className="space-y-1">
                {/* Login Item */}
                <button
                  onClick={() => {
                    if (onLogin) {
                      onLogin();
                    } else {
                      onSelectService(ServiceType.CARD_PIN_GENERATION);
                    }
                    onClose();
                  }}
                  className="w-full flex items-center justify-between px-5 py-4 rounded-xl transition-all duration-200 text-left cursor-pointer group bg-rose-50/50 hover:bg-rose-100/40 text-[#AE275F] border border-dashed border-[#AE275F]/30 mb-3"
                  id="sidebar-item-login"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-8 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <LogIn className="w-6 h-6 text-[#AE275F]" />
                    </div>
                    <div>
                      <p className="font-bold text-[#AE275F] text-sm md:text-base tracking-tight">
                        Login / Verification
                      </p>
                      <p className="text-[11px] text-[#AE275F]/70 font-semibold leading-none mt-0.5">
                        Access details & verify card
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#AE275F] group-hover:translate-x-0.5 transition-transform" />
                </button>

                <div className="h-[1px] bg-gray-100 my-3" />

                {SERVICES_LIST.map((service) => {
                  const isActive = activeService === service.type;
                  return (
                    <button
                      key={service.type}
                      onClick={() => {
                        onSelectService(service.type);
                        onClose();
                      }}
                      className={`w-full flex items-center justify-between px-5 py-4 rounded-xl transition-all duration-200 text-left cursor-pointer group ${
                        isActive 
                          ? 'bg-rose-50/50 text-[#AE275F]' 
                          : 'hover:bg-gray-50'
                      }`}
                      id={`sidebar-item-${service.type}`}
                    >
                      <div className="flex items-center gap-4">
                        {/* Icon Wrapper */}
                        <div className="w-8 flex items-center justify-center group-hover:scale-105 transition-transform">
                          {renderIcon(service.iconName)}
                        </div>
                        
                        {/* Title */}
                        <div>
                          <p className="font-semibold text-gray-700 text-sm md:text-base tracking-tight">
                            {service.title}
                          </p>
                        </div>
                      </div>

                      {/* Right Indicator Arrow */}
                      <ChevronRight className="w-4 h-4 text-gray-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Sticky footer */}
            <div className="p-4 border-t border-gray-100 bg-gray-50/50 text-center" id="sidebar-footer">
              <p className="text-[11px] text-gray-400 font-medium">
                Secure SSL 256-Bit Encrypted Session
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
