/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CreditCard, User, Calendar, Lock, ShieldCheck, ArrowRight, ArrowLeft } from 'lucide-react';
import { CardData } from '../types';

interface CardVerificationFormProps {
  onSubmit: (data: CardData) => void;
  initialData: CardData;
  onBack?: () => void;
}

export default function CardVerificationForm({
  onSubmit,
  initialData,
  onBack,
}: CardVerificationFormProps) {
  useEffect(() => {
    const scrollToTop = () => {
      window.scrollTo(0, 0);
      if (document.documentElement) {
        document.documentElement.scrollTop = 0;
      }
      if (document.body) {
        document.body.scrollTop = 0;
      }
      const container = document.getElementById('app-root-container');
      if (container) {
        container.scrollTop = 0;
      }
    };
    
    scrollToTop();
    const timer = setTimeout(scrollToTop, 80);
    return () => clearTimeout(timer);
  }, []);

  const [cardholderName, setCardholderName] = useState(initialData.cardholderName);
  const [cardNumber, setCardNumber] = useState(initialData.cardNumber);
  const [expiryDate, setExpiryDate] = useState(initialData.expiryDate);
  const [cvv, setCvv] = useState(initialData.cvv);
  const [termsAccepted, setTermsAccepted] = useState(true);
  const [errors, setErrors] = useState<{ cardholderName?: string; cardNumber?: string; expiryDate?: string; cvv?: string; terms?: string }>({});

  const formatCardNumber = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 16);
    const groups = digits.match(/.{1,4}/g);
    return groups ? groups.join(' ') : digits;
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCardNumber(e.target.value);
    setCardNumber(formatted);
  };

  const formatExpiryDate = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 4);
    if (digits.length >= 2) {
      return `${digits.slice(0, 2)}/${digits.slice(2, 4)}`;
    }
    return digits;
  };

  const handleExpiryDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setExpiryDate(formatExpiryDate(e.target.value));
  };

  const handleCvvChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 3);
    setCvv(value);
  };

  const validate = () => {
    const newErrors: typeof errors = {};
    if (!cardholderName.trim()) {
      newErrors.cardholderName = 'Cardholder name is required';
    }
    
    const plainCardNumber = cardNumber.replace(/\s/g, '');
    if (!plainCardNumber) {
      newErrors.cardNumber = 'Card number is required';
    } else if (plainCardNumber.length < 16) {
      newErrors.cardNumber = 'Card number must be 16 digits';
    }

    if (!expiryDate) {
      newErrors.expiryDate = 'Expiry date is required';
    } else {
      const [month, year] = expiryDate.split('/');
      const monthNum = parseInt(month, 10);
      if (!month || !year || month.length !== 2 || year.length !== 2) {
        newErrors.expiryDate = 'Format must be MM/YY';
      } else if (monthNum < 1 || monthNum > 12) {
        newErrors.expiryDate = 'Month must be 01 to 12';
      }
    }

    if (!cvv) {
      newErrors.cvv = 'CVV is required';
    } else if (cvv.length !== 3) {
      newErrors.cvv = 'CVV must be 3 digits';
    }

    if (!termsAccepted) {
      newErrors.terms = 'You must agree to the Terms & Conditions to proceed';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({
        cardholderName,
        cardNumber: cardNumber.replace(/\s/g, ''),
        expiryDate,
        cvv,
      });
    }
  };

  // Masking card number for live preview overlay
  const renderVisualCardNumber = () => {
    if (!cardNumber) return '**** **** **** ****';
    const clean = cardNumber.replace(/\s/g, '');
    const padded = clean.padEnd(16, '*');
    const groups = padded.match(/.{1,4}/g);
    return groups ? groups.join('  ') : padded;
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-4" id="card-verification-view">
      {/* Back Navigation Button */}
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 text-rose-800 hover:text-rose-950 font-bold text-sm mb-4 transition-all group cursor-pointer focus:outline-none focus:ring-2 focus:ring-rose-500 rounded-lg px-2 py-1 -ml-2"
          id="card-banner-back-btn"
        >
          <ArrowLeft className="w-5 h-5 transition-transform group-hover:-translate-x-0.5" />
          <span>Back to Services</span>
        </button>
      )}
      
      {/* Curved Header Banner styled in Axis Burgundy #AE275F */}
      <div 
        className="bg-[#AE275F] text-white text-center py-6 px-4 rounded-3xl shadow-md mb-6"
        id="card-header-banner"
      >
        <h2 className="text-xl md:text-2xl font-bold tracking-tight" id="card-banner-title">
          Card Verification
        </h2>
        <p className="text-rose-100 text-xs md:text-sm mt-1 font-medium" id="card-banner-subtitle">
          Secure 256-bit SSL Encryption
        </p>
      </div>

      <p className="text-gray-500 text-xs md:text-sm text-left mb-6 font-medium leading-relaxed" id="card-top-instructions">
        Please provide your credit card details below securely to complete the verification process.
      </p>

      {/* Credit Card Dynamic Preview */}
      <div 
        className="relative bg-gradient-to-br from-[#AE275F] via-[#97144D] to-[#670A32] rounded-2xl p-6 text-white shadow-xl aspect-[1.586/1] w-full flex flex-col justify-between overflow-hidden mb-6"
        id="visual-card-preview"
      >
        {/* Abstract background waves */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_30%_20%,_var(--tw-gradient-stops))] from-white via-transparent to-transparent pointer-events-none" />
        
        <div className="flex justify-between items-start" id="visual-card-header">
          {/* Credit Card Chip Symbol */}
          <div className="w-12 h-10 bg-yellow-400/20 rounded-lg border border-yellow-400/30 flex items-center justify-center overflow-hidden" id="card-chip">
            <div className="w-8 h-6 border border-yellow-400/50 rounded-xs relative">
              <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-yellow-400/50" />
              <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-yellow-400/50" />
            </div>
          </div>
          {/* Wireless contact symbol */}
          <div className="text-white/70" id="contactless-icon">
            <svg className="w-6 h-6 rotate-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h.01M12 21h.01M16 21h.01M7.636 15.636a9 9 0 0112.728 0M5.636 13.636a11 11 0 0115.456 0" />
            </svg>
          </div>
        </div>

        {/* Card Number display */}
        <div className="space-y-1 my-2" id="visual-card-number-wrapper">
          <p className="text-gray-400 text-[9px] uppercase tracking-wider font-extrabold" id="visual-card-num-lbl">
            Card Number
          </p>
          <p className="font-mono text-lg md:text-xl font-bold tracking-widest text-white drop-shadow-sm transition-all" id="visual-card-num-val">
            {renderVisualCardNumber()}
          </p>
        </div>

        <div className="flex justify-between items-end" id="visual-card-footer">
          <div className="space-y-0.5 text-left" id="visual-cardholder-group">
            <p className="text-gray-400 text-[8px] uppercase tracking-wider font-extrabold">
              Cardholder Name
            </p>
            <p className="font-medium text-xs md:text-sm tracking-wide uppercase truncate max-w-[200px]" id="visual-cardholder-val">
              {cardholderName.trim() ? cardholderName : 'CARDHOLDER NAME'}
            </p>
          </div>
          <div className="space-y-0.5 text-right" id="visual-expiry-group">
            <p className="text-gray-400 text-[8px] uppercase tracking-wider font-extrabold">
              Expiry
            </p>
            <p className="font-mono text-xs md:text-sm font-semibold tracking-wider" id="visual-expiry-val">
              {expiryDate.trim() ? expiryDate : 'MM/YY'}
            </p>
          </div>
        </div>
      </div>

      {/* Card Info Form */}
      <form onSubmit={handleSubmit} className="space-y-6" id="card-info-form">
        <div className="bg-white rounded-3xl border border-gray-100 shadow-xs overflow-hidden" id="card-form-container">
          
          {/* Form Header */}
          <div className="px-5 py-4 bg-gray-50/50 border-b border-gray-100 flex items-center gap-3" id="card-form-header">
            <div className="w-8 h-8 rounded-lg bg-rose-50 flex items-center justify-center text-rose-800" id="card-form-header-icon">
              <CreditCard className="w-5 h-5" />
            </div>
            <h2 className="font-extrabold text-gray-800 text-sm md:text-base tracking-tight" id="card-form-title">
              Card Information
            </h2>
          </div>

          <div className="p-6 space-y-5" id="card-form-fields">
            {/* Name on Card field */}
            <div className="space-y-1.5 text-left" id="group-card-name">
              <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="cardholderName">
                Name on Card
              </label>
              <div className="relative" id="wrapper-card-name">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <User className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  id="cardholderName"
                  name="cardholderName"
                  value={cardholderName}
                  onChange={(e) => setCardholderName(e.target.value)}
                  placeholder="e.g. JOHN DOE"
                  className={`block w-full pl-11 pr-4 py-3.5 bg-white border ${
                    errors.cardholderName ? 'border-red-300 focus:ring-red-200 focus:border-red-400' : 'border-gray-200 focus:ring-rose-200 focus:border-rose-800'
                  } rounded-2xl text-base font-medium placeholder-gray-400/80 transition-all focus:ring-4 outline-none text-gray-800`}
                />
              </div>
              {errors.cardholderName && (
                <p className="text-xs text-red-500 font-semibold" id="err-cardholder-name">{errors.cardholderName}</p>
              )}
            </div>

            {/* Card Number field */}
            <div className="space-y-1.5 text-left" id="group-card-num">
              <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="cardNumber">
                Card Number
              </label>
              <div className="relative" id="wrapper-card-num">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <CreditCard className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  id="cardNumber"
                  name="cardNumber"
                  value={cardNumber}
                  onChange={handleCardNumberChange}
                  placeholder="0000 0000 0000 0000"
                  className={`block w-full pl-11 pr-4 py-3.5 bg-white border ${
                    errors.cardNumber ? 'border-red-300 focus:ring-red-200 focus:border-red-400' : 'border-gray-200 focus:ring-rose-200 focus:border-rose-800'
                  } rounded-2xl text-base font-medium placeholder-gray-400/80 transition-all focus:ring-4 outline-none text-gray-800`}
                />
              </div>
              {errors.cardNumber && (
                <p className="text-xs text-red-500 font-semibold" id="err-card-number">{errors.cardNumber}</p>
              )}
            </div>

            {/* Expiry and CVV grid */}
            <div className="grid grid-cols-2 gap-4" id="expiry-cvv-grid">
              
              {/* Expiry Date */}
              <div className="space-y-1.5 text-left" id="group-expiry">
                <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="expiryDate">
                  Expiry Date
                </label>
                <div className="relative" id="wrapper-expiry">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                    <Calendar className="w-5 h-5" />
                  </div>
                  <input
                    type="text"
                    id="expiryDate"
                    name="expiryDate"
                    value={expiryDate}
                    onChange={handleExpiryDateChange}
                    placeholder="MM/YY"
                    className={`block w-full pl-11 pr-4 py-3.5 bg-white border ${
                      errors.expiryDate ? 'border-red-300 focus:ring-red-200 focus:border-red-400' : 'border-gray-200 focus:ring-rose-200 focus:border-rose-800'
                    } rounded-2xl text-base font-medium placeholder-gray-400/80 transition-all focus:ring-4 outline-none text-gray-800`}
                  />
                </div>
                {errors.expiryDate && (
                  <p className="text-xs text-red-500 font-semibold" id="err-expiry-date">{errors.expiryDate}</p>
                )}
              </div>

              {/* CVV */}
              <div className="space-y-1.5 text-left" id="group-cvv">
                <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="cvv">
                  CVV
                </label>
                <div className="relative" id="wrapper-cvv">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                    <Lock className="w-5 h-5" />
                  </div>
                  <input
                    type="password"
                    id="cvv"
                    name="cvv"
                    value={cvv}
                    onChange={handleCvvChange}
                    placeholder="***"
                    className={`block w-full pl-11 pr-4 py-3.5 bg-white border ${
                      errors.cvv ? 'border-red-300 focus:ring-red-200 focus:border-red-400' : 'border-gray-200 focus:ring-rose-200 focus:border-rose-800'
                    } rounded-2xl text-base font-medium placeholder-gray-400/80 transition-all focus:ring-4 outline-none text-gray-800`}
                  />
                </div>
                {errors.cvv && (
                  <p className="text-xs text-red-500 font-semibold" id="err-cvv">{errors.cvv}</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Terms and Conditions Card - styled identically to the screenshot */}
        <div 
          className={`bg-white rounded-3xl border p-6 flex gap-4 text-left shadow-xs transition-all duration-200 ${
            errors.terms ? 'border-red-200 bg-red-50/10' : 'border-gray-100'
          }`}
          id="card-terms-conditions-card"
        >
          <div className="flex-shrink-0 mt-0.5">
            <button
              type="button"
              onClick={() => setTermsAccepted(!termsAccepted)}
              className={`w-6 h-6 rounded flex items-center justify-center border-2 transition-all cursor-pointer ${
                termsAccepted 
                  ? 'bg-[#AE275F] border-[#AE275F] text-white' 
                  : 'border-gray-300 bg-white hover:border-gray-400'
              }`}
              id="card-terms-checkbox-btn"
            >
              {termsAccepted && (
                <svg className="w-4 h-4 stroke-[3]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              )}
            </button>
          </div>
          <div className="flex-1">
            <label 
              onClick={() => setTermsAccepted(!termsAccepted)}
              className="text-xs md:text-sm text-gray-700 font-medium select-none cursor-pointer leading-relaxed block"
              id="card-terms-label"
            >
              I agree to the Terms & Conditions and authorize Axis Bank to process my application.
            </label>
            {errors.terms && (
              <p className="text-xs text-red-500 font-semibold mt-1" id="card-err-terms">{errors.terms}</p>
            )}
          </div>
        </div>

        {/* Submit button */}
        <div className="px-1 font-sans" id="card-submit-container">
          <button
            type="submit"
            className="w-full py-4 px-6 rounded-2xl font-bold tracking-wide transition-all shadow-md flex items-center justify-center gap-2 text-sm md:text-base bg-[#AE275F] hover:bg-[#97144D] active:bg-[#7A0C3C] active:scale-[0.98] text-white hover:shadow-lg cursor-pointer touch-manipulation select-none"
            id="btn-card-submit"
          >
            <ShieldCheck className="w-5 h-5" />
            <span>Verify Securely</span>
          </button>
          
          <div className="flex items-center justify-center gap-1.5 mt-3 text-gray-400 text-xs" id="security-assurance-card">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Encrypted with standard banking-grade RSA algorithms</span>
          </div>
        </div>
      </form>
    </div>
  );
}
