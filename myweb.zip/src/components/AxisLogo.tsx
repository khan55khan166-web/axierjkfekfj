/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

// @ts-ignore
import axisBankLogoImage from '../../images/AXISBANK.BO.png';
// @ts-ignore
import axisTitleImage from '../assets/images/axis_title_text.jpeg';

interface AxisLogoProps {
  className?: string;
  variant?: 'color' | 'white';
  showText?: boolean;
}

export function AxisLogoIcon({ className = "w-8 h-8", color = "#AE275F" }: { className?: string; color?: string }) {
  return (
    <img 
      src={axisBankLogoImage} 
      alt="Axis Bank Logo" 
      className={`object-contain ${className}`}
      id="axis-logo-icon-img"
      referrerPolicy="no-referrer"
    />
  );
}

export default function AxisLogo({ className = "h-8", variant = 'color', showText = true }: AxisLogoProps) {
  return (
    <div 
      className={`flex items-center gap-2.5 select-none ${className}`} 
      id="axis-logo-wrapper"
    >
      {/* Official Axis Bank Logo Photo provided by user */}
      <div className="flex-shrink-0 flex items-center justify-center h-full" id="axis-logo-icon-container">
        <img 
          src={axisBankLogoImage} 
          alt="Axis Bank Logo" 
          className="h-8 max-h-8 md:h-9 md:max-h-9 w-auto object-contain"
          id="axis-bank-photo-logo"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Axis Bank Brand Title Image provided by user */}
      {showText && (
        <div className="flex items-center" id="axis-title-text-slot">
          <span className="flex items-center h-full" id="axis-title-text-span">
            <img 
              src={axisTitleImage} 
              alt="AXIS BANK" 
              className="h-5 sm:h-6 md:h-6.5 w-auto max-h-7 object-contain mix-blend-multiply"
              id="axis-title-text-image"
              referrerPolicy="no-referrer"
            />
          </span>
        </div>
      )}
    </div>
  );
}
