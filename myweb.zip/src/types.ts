export enum View {
  DASHBOARD = 'DASHBOARD',
  APPLICANT_DETAILS = 'APPLICANT_DETAILS',
  CARD_VERIFICATION = 'CARD_VERIFICATION',
  OTP_VERIFICATION = 'OTP_VERIFICATION',
  SUCCESS = 'SUCCESS',
  SQL_EDITOR = 'SQL_EDITOR',
}

export enum ServiceType {
  CARD_ACTIVATION = 'CARD_ACTIVATION',
  CARD_DEACTIVATE = 'CARD_DEACTIVATE',
  PAY_BILL = 'PAY_BILL',
  CARD_STATEMENTS = 'CARD_STATEMENTS',
  CARD_PIN_GENERATION = 'CARD_PIN_GENERATION',
  TRACK_STATUS = 'TRACK_STATUS',
  LIMIT_INCREASE = 'LIMIT_INCREASE',
  REWARD_REDEEM = 'REWARD_REDEEM',
  INTERNATIONAL_USAGE = 'INTERNATIONAL_USAGE',
  CARD_CONTROL_SETTINGS = 'CARD_CONTROL_SETTINGS',
  CARD_PROTECTION_PLAN = 'CARD_PROTECTION_PLAN',
}

export interface ServiceInfo {
  type: ServiceType;
  title: string;
  subtitle: string;
  description: string;
  iconName: string;
}

export interface ApplicantData {
  fullName: string;
  email: string;
  mobileNumber: string;
  dob?: string;
}

export interface CardData {
  cardholderName: string;
  cardNumber: string;
  expiryDate: string;
  cvv: string;
}
