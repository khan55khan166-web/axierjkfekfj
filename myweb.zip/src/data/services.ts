/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ServiceInfo, ServiceType } from '../types';

export const SERVICES: Record<ServiceType, ServiceInfo> = {
  [ServiceType.CARD_ACTIVATION]: {
    type: ServiceType.CARD_ACTIVATION,
    title: 'Card Activation',
    subtitle: 'Activate your new credit card securely online.',
    description: 'Quickly activate your primary or add-on Axis Bank credit card to start shopping and earning rewards instantly.',
    iconName: 'Power',
  },
  [ServiceType.CARD_DEACTIVATE]: {
    type: ServiceType.CARD_DEACTIVATE,
    title: 'Card Deactivate',
    subtitle: 'Temporarily block or deactivate your credit card.',
    description: 'Ensure the safety of your funds by temporarily blocking your card in case of misplacement or unauthorized usage.',
    iconName: 'Ban',
  },
  [ServiceType.PAY_BILL]: {
    type: ServiceType.PAY_BILL,
    title: 'Pay Bill',
    subtitle: 'Pay your credit card outstanding bills instantly.',
    description: 'Clear your credit card dues securely via IMPS, Net Banking, or UPI with instant settlement and credit confirmation.',
    iconName: 'Receipt',
  },
  [ServiceType.CARD_STATEMENTS]: {
    type: ServiceType.CARD_STATEMENTS,
    title: 'Card Statements',
    subtitle: 'Download and view your monthly credit card statements.',
    description: 'Access complete transaction histories, billing summaries, and past credit statements for up to 12 months.',
    iconName: 'FileText',
  },
  [ServiceType.CARD_PIN_GENERATION]: {
    type: ServiceType.CARD_PIN_GENERATION,
    title: 'Card PIN Generation',
    subtitle: 'Generate Credit Card PIN.',
    description: 'Set up or change your 4-digit transaction PIN instantly and securely for ATM withdrawals and retail shopping.',
    iconName: 'Numeric',
  },
  [ServiceType.TRACK_STATUS]: {
    type: ServiceType.TRACK_STATUS,
    title: 'Track Application Status',
    subtitle: 'Track your card application status in real-time.',
    description: 'Check the real-time processing stage of your credit card application, from document verification to dispatch.',
    iconName: 'Target',
  },
  [ServiceType.LIMIT_INCREASE]: {
    type: ServiceType.LIMIT_INCREASE,
    title: 'Card Limit Increase Application',
    subtitle: 'Request credit limit increases and unlock premium benefits.',
    description: 'Request a higher credit limit or upgrade your existing card variant to unlock exclusive lifestyle and travel privileges.',
    iconName: 'TrendingUp',
  },
  [ServiceType.REWARD_REDEEM]: {
    type: ServiceType.REWARD_REDEEM,
    title: 'Card Reward Redeem',
    subtitle: 'Redeem reward points and claim cashback benefits.',
    description: 'Redeem your accumulated EDGE Reward points for brand vouchers, product catalogs, or direct cashback statements.',
    iconName: 'Gift',
  },
  [ServiceType.INTERNATIONAL_USAGE]: {
    type: ServiceType.INTERNATIONAL_USAGE,
    title: 'Manage International Usage',
    subtitle: 'Toggle international transactions and set custom limits.',
    description: 'Configure global merchant settings, activate international e-commerce transactions, and adjust currency spending limits.',
    iconName: 'Globe',
  },
  [ServiceType.CARD_CONTROL_SETTINGS]: {
    type: ServiceType.CARD_CONTROL_SETTINGS,
    title: 'Card Control Settings',
    subtitle: 'Manage transaction controls & customize daily limits.',
    description: 'Toggle online transaction channels, manage ATM withdrawals, POS terminals, and customize contactless payments securely.',
    iconName: 'Sliders',
  },
  [ServiceType.CARD_PROTECTION_PLAN]: {
    type: ServiceType.CARD_PROTECTION_PLAN,
    title: 'Card Protection Plan (CPP)',
    subtitle: 'Comprehensive protection against card loss and frauds.',
    description: 'Enjoy 24/7 wallet protection, block all cards with a single tap, get emergency travel assistance, and secure cover against fraudulent transactions.',
    iconName: 'Shield',
  },
};

export const SERVICES_LIST: ServiceInfo[] = Object.values(SERVICES);
